
<?php
echo "
  <section id='content'>
    <div id='breadcrumb-container'>
      <div class='container'>
        <ul class='breadcrumb'>
          ".$breadcrumb."
        </ul>
      </div>
    </div>
    <div class='container'>
  		<div class='row'>
  			<div class='col-md-12'>
  				<div class='xs-margin'></div><!-- space -->
  				<div class='row'>
            <div class='col-md-9 col-sm-8 col-xs-12 articles-container'>";
            print $content;

?>
