<?php
$sidebar="
<div class='left-sidebar-pro'>
  <nav id='sidebar'>
    <div class='sidebar-header'>
      <a href='index.php'>
        <img class='main-logo' src='view/style/img/logo/logo.png' alt='' />
      </a>
    </div>
    <div class='left-custom-menu-adp-wrap comment-scrollbar'>
      <nav class='sidebar-nav left-sidebar-menu-pro'>
        <ul class='metismenu' id='menu1'>
          <li>
            <a href='index.php'>
             <i class='fa big-icon fa-home icon-wrap'></i>
             <span class='mini-click-non'>AnaSayfa</span>
            </a>
          </li>
          <li>
            <a class='has-arrow'>
              <i class='fa big-icon fa-gears icon-wrap'></i>
              <span class='mini-click-non'>Menu İşlemleri</span>
            </a>
            <ul class='submenu-angle' aria-expanded='true'>
              <li>
                <a title='mavrosoft' href='?m=menu'>
                  <i class='fa fa-gg sub-icon-mg' aria-hidden='true'></i>
                  <span class='mini-sub-pro'>Menü Ayarları</span>
                </a>
              </li>
              <li>
                <a title='Kategori Ayarları' href='?m=kategori'>
                  <i class='fa fa-certificate sub-icon-mg' aria-hidden='true'></i>
                  <span class='mini-sub-pro'>Kategori Ayarları</span>
                </a>
              </li>
            </ul>
          </li>
          <li>
            <a class='has-arrow'>
               <i class='fa big-icon fa-tags icon-wrap'></i>
               <span class='mini-click-non'>Etiket İşlemleri</span>
            </a>
            <ul class='submenu-angle' aria-expanded='true'>
              <li>
                <a title='Etiket Ayarları' href='?m=etiket'>
                  <i class='fa fa-tags sub-icon-mg' aria-hidden='true'></i>
                  <span class='mini-sub-pro'>Etiket Ayarları</span>
                </a>
              </li>
              <li>
                <a title='Etiket Ayarları' href='?m=etiketgrup'>
                  <i class='fa fa-object-group sub-icon-mg' aria-hidden='true'></i>
                  <span class='mini-sub-pro'>Gorup Ayarları</span>
                </a>
              </li>
            </ul>
          </li>
          <li>
            <a class='has-arrow'>
               <i class='fa big-icon fa-file icon-wrap'></i>
               <span class='mini-click-non'>Makale İşlemleri</span>
            </a>
            <ul class='submenu-angle' aria-expanded='true'>
            <li>
                <a title='mavrosoft' href='?m=makale/yenimakale/0'>
                  <i class='fa fa-file-text sub-icon-mg' aria-hidden='true'></i>
                  <span class='mini-sub-pro'>Yeni Makale</span>
                </a>
              </li>
              <li>
                <a title='Kategori Ayarları' href='?m=makale/listele'>
                  <i class='fa fa-list sub-icon-mg' aria-hidden='true'></i>
                  <span class='mini-sub-pro'>Makaleleri Listele</span>
                </a>
              </li>
            </ul>
          </li>
          <li>
            <a title='Görüş Ayarları' href='?m=ozlusoz'>
             <i class='fa big-icon fa-bookmark icon-wrap'></i>
             <span class='mini-click-non'>Özlü Söz İşlemleri</span>
            </a>
          </li>
          <li>
            <a class='has-arrow'>
              <i class='fa big-icon fa-video-camera icon-wrap'></i>
              <span class='mini-click-non'>Media İşlemleri</span>
            </a>
            <ul class='submenu-angle' aria-expanded='true'>
              <li>
                <a title='mavrosoft' href='?m=media/image'>
                  <i class='fa fa-picture-o sub-icon-mg' aria-hidden='true'></i>
                  <span class='mini-sub-pro'>İmage İşlemleri</span>
                </a>
              </li>
            </ul>
          </li>
          <li>
            <a href='?m=kullanicilar' title='Kullanıcı Ayarları' href='#' aria-expanded='false'>
            <i class='fa big-icon fa-users icon-wrap' aria-hidden='true'></i>
            <span  class='mini-click-non'>Kullanıcı İşlemleri</span></a>
          </li>
          <li>
            <a href='login/logout.php' title='Çıkış Yap' href='#' aria-expanded='false'>
            <i class='fa fa-power-off icon-wrap sub-icon-mg' aria-hidden='true'></i>
            <span  class='mini-click-non'>Log Out</span></a>
          </li>
        </ul>
      </nav>
    </div>
  </nav>
</div>";
print $sidebar;

?>
