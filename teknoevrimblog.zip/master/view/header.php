<?php
$header="
<!doctype html>
<html class='no-js' lang='tr'>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='x-ua-compatible' content='ie=edge'>
    <title>TeknoEvrim Master</title>
    <meta name='description' content=''>
    <meta name='viewport' content='width=device-width, initial-scale=1'>

		<!-- ============== favicon CSS ======================== -->
    <link rel='shortcut icon' type='image/x-icon' href='".loginstyle."img/favicon.ico'>

		<!-- ============== Google Fonts CSS ======================== -->
    <link href='https://fonts.googleapis.com/css?family=Play:400,700' rel='stylesheet'>

    <!-- ============== sweetalert2 CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/sweetalert2.min.css'>

		<!-- ============== Bootstrap CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/bootstrap.min.css'>
    <link rel='stylesheet' href='".loginstyle."css/font-awesome.min.css'>

		<!-- ============== owl.carousel CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/owl.carousel.css'>
    <link rel='stylesheet' href='".loginstyle."css/owl.theme.css'>
    <link rel='stylesheet' href='".loginstyle."css/owl.transitions.css'>

		<!-- ============== animate CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/animate.css'>

		<!-- ============== normalize CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/normalize.css'>

		<!-- ============== meanmenu icon CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/meanmenu.min.css'>

		<!-- ============== main CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/main.css'>

		<!-- ============== morrisjs CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/morrisjs/morris.css'>

		<!-- ============== datatable CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/datatable/jquery.dataTables.min.css'>
    <link rel='stylesheet' href='".loginstyle."css/datatable/responsive.dataTables.min.css'>
    <link rel='stylesheet' href='".loginstyle."css/datatable/rowReorder.dataTables.min.css'>

		<!-- ============== datapicker CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/datapicker/datepicker3.css'>

		<!-- ============== modals CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/modals.css'>

    <!-- ============== summernote CSS  ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/summernote/summernote.css>

	  <!-- ============== mCustomScrollbar CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/scrollbar/jquery.mCustomScrollbar.min.css'>

	  <!-- ============== metisMenu CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/metisMenu/metisMenu.min.css'>
    <link rel='stylesheet' href='".loginstyle."css/metisMenu/metisMenu-vertical.css'>

		<!-- ============== calendar CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/calendar/fullcalendar.min.css'>
    <link rel='stylesheet' href='".loginstyle."css/calendar/fullcalendar.print.min.css'>

		<!-- ============== forms CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/form/all-type-forms.css'>

    <!-- ============== style CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/style.css'>

		<!-- ============== responsive CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/responsive.css'>

		<!-- ============== modernizr CSS ======================== -->
    <script src='".loginstyle."js/vendor/modernizr-2.8.3.min.js'></script>

    <!-- ============== dropify CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."plugins/dropify/dropify.css'>

    <!-- ============== chosen CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."css/chosen/bootstrap-chosen.css'>
    <link rel='stylesheet' href='".loginstyle."css/chosen/chosenImage.css'>

    <!-- ============== select2 CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."plugins/select2/css/select2.min.css'>

    <!-- ============== select2 CSS ======================== -->
    <link rel='stylesheet' href='".loginstyle."plugins/powertip/jquery.powertip-dark.css'>


</head>
<body>
";
print $header;
?>
