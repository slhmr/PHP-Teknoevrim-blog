function girisyap(){
  var kullaniciadi=$("input[name=kullaniciadi]").val();
  var kullanicisifre=$("input[name=kullanicisifre]").val();
  var formData = {
		  'kullaniciadi'    : kullaniciadi,
      'kullanicisifre'  : kullanicisifre,
	};
  if(kullaniciadi == ""){
    Swal.fire('Ooops!','Kullanıcı Adı Boş Bırakılmaz...','info');
    return false;
  }else if(kullanicisifre == ""){
    Swal.fire('Ooops!','Kullanıcı Şifresi Boş Bırakılamaz...','info');
    return false;
  }else{
    $.ajax({
      type : 'POST',
      url  : 'loginprocess.php',
      data : formData,
      dataType: 'json',
      beforeSend: function(){
        $(".loginbtn").html('<span class="fa fa-eye"></span> &nbsp; Kontrol Ediliyor');
      },
      success :  function(data){
        if(data.durum == "success"){
          $(".loginbtn").html("<img src='../view/style/img/loader.gif' /> &emsp; Giriş Yapılıyor ...");
          setTimeout(' window.location.href = "../index.php"; ',1000);
        }
        else{
        $("div.result").fadeIn(500, function(){
  				  $("div.result").html(data.durum);
  				  setTimeout(' window.location.href = "login.php"; ',2000);
          });
          console.log("1");
        }
      }
    });
  }
}
