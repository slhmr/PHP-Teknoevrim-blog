/******************************************/
function sayfayiyenile(deger){setTimeout(function () {location.reload()}, deger)}
function geridon(){history.back()}
function ileri() {window.history.forward()}
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

/******************************************/
/*          Menu İşlemleri                */
/******************************************/
function showcategories(id){
  var formData = {
    'id' : id,
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=showcategori',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      $(".modal-primary").html(data.modal).modal('show');
    }
  });
}
function menuislem(id,islem){
  var formData = {
    'id'    : id,
    'islem' : islem,
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=menuedit',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      $(".modal-info").html(data.modal).modal('show');
    }
  });
}
function bilgilerikaydet(id,islem){
  var formData = {
    'id'        : id,
    'islem'     : islem,
    'menuadi'   : $("input[name=menuadi]").val(),
    'menulink'  : $("input[name=menulink]").val(),
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=bilgilerikaydet',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      if(data.durum == "success"){
        Swal.fire({
          position: 'center',
          icon: data.durum,
          title: data.mesaj,
          text: data.aciklama,
          showConfirmButton: false,
          timer: 1500
        });
          sayfayiyenile(1600);

      }
      else{
        Swal.fire({icon: data.durum,title: data.mesaj,text: data.aciklama});
      }
    }
  });
}
function menusil(id){
  Swal.fire({
    title : 'Silmek İstediğine Emin misin?',
    text  : "Silme İşlemi Sonunda, Silinen Menuye Bağlı Tüm Kategoriler, Etiketler ve Gönderilerin Bağlantısı Kopmaktadır. Tüm Gönderiler İçin Tekrar Ayar Yapılması Gerekmektedir...",
    icon  : 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Evet, Sil!',
    cancelButtonText: 'İptal Et!',
    reverseButtons: true
  }).then((result) => {
    if (result.value) {
      var formData = {
        'id'        : id,
      }
      $.ajax({
        type: 'POST',
        url : 'inc/ajax.php?mstr=menusil',
        data: formData,
        dataType: 'JSON',
        success:function(data){
          if(data.durum == "success"){
            Swal.fire({
              position: 'center',
              icon: data.durum,
              title: data.mesaj,
              text: data.aciklama,
              showConfirmButton: false,
              timer: 1500
            });
              sayfayiyenile(1600);
          }
          else{
            Swal.fire(data.mesaj,data.aciklama,data.durum);
          }
        }
      });
    } else if (
      result.dismiss === Swal.DismissReason.cancel
    ){
      Swal.fire(
        'İptal Edildi',
        'Menu Silme İşlemi Başlamadan Sonlandırıldı..',
        'info'
      )
    }
  });
}
/******************************************/
/*       Kategori İşlemleri               */
/******************************************/
function kategoriislem(id,islem){
  var formData = {
    'catid'     : id,
    'islem'     : islem,
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=kategoriislem',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      $(".modal-info").html(data.modal).modal('show');
      $('.chosen-select').chosen({width: "100%"});
    }
  });
}
function kategoribilgilerikaydet(id,islem){
  var formData = {
    'catid'     : id,
    'islem'     : islem,
    'catadi'    : $("input[name=catadi]").val(),
    'catlink'   : $("input[name=catlink]").val(),
    'catmenuid'   : $("#kategorimenu").val(),
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=kategoribilgikaydet',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      if(data.durum == "success"){
        Swal.fire({
          position: 'center',
          icon: data.durum,
          title: data.mesaj,
          text: data.aciklama,
          showConfirmButton: false,
          timer: 1500
        });
          sayfayiyenile(1600);

      }
      else{
        Swal.fire({icon: data.durum,title: data.mesaj,text: data.aciklama});
      }
    }
  });
}
function kategorisil(id){
  Swal.fire({
    title : 'Silmek İstediğine Emin misin?',
    text  : "Silme İşlemi Sonunda, Silinen Kategoriye Bağlı Tüm Etiketler ve Gönderilerin Bağlantısı Kopmaktadır. Tüm Gönderiler İçin Tekrar Ayar Yapılması Gerekmektedir...",
    icon  : 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Evet, Sil!',
    cancelButtonText: 'İptal Et!',
    reverseButtons: true
  }).then((result) => {
    if (result.value) {
      var formData = {
        'id'        : id,
      }
      $.ajax({
        type: 'POST',
        url : 'inc/ajax.php?mstr=kategorisil',
        data: formData,
        dataType: 'JSON',
        success:function(data){
          if(data.durum == "success"){
            Swal.fire({
              position: 'center',
              icon: data.durum,
              title: data.mesaj,
              text: data.aciklama,
              showConfirmButton: false,
              timer: 1500
            });
              sayfayiyenile(1600);
          }
          else{
            Swal.fire(data.mesaj,data.aciklama,data.durum);
          }
        }
      });
    } else if (
      result.dismiss === Swal.DismissReason.cancel
    ){
      Swal.fire(
        'İptal Edildi',
        'Kategori Silme İşlemi Başlamadan Sonlandırıldı..',
        'info'
      )
    }
  });
}
/******************************************/
/*       Etiket İşlemleri                 */
/******************************************/
function etiketislem(id,islem){
  var formData = {
    'tagid'     : id,
    'islem'     : islem,
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=etiketislem',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      $(".modal-info").html(data.modal).modal('show');
      $('.chosen-select').chosen({width: "100%"});
    }
  });
}
function etiketbilgikaydet(id,islem){
  var formData = {
    'tagid'     : id,
    'islem'     : islem,
    'tagadi'    : $("input[name=tagadi]").val(),
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=etiketbilgikaydet',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      if(data.durum == "success"){
        Swal.fire({
          position: 'center',
          icon: data.durum,
          title: data.mesaj,
          text: data.aciklama,
          showConfirmButton: false,
          timer: 1500
        });
          sayfayiyenile(1600);

      }
      else{
        Swal.fire({icon: data.durum,title: data.mesaj,text: data.aciklama});
      }
    }
  });
}
function etiketsil(id){
  Swal.fire({
    title : 'Silmek İstediğine Emin misin?',
    text  : "Silme İşlemi Sonunda, Gönderide Kullanılan Etiketler Yeniden Ayarlanamlıdır...",
    icon  : 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Evet, Sil!',
    cancelButtonText: 'İptal Et!',
    reverseButtons: true
  }).then((result) => {
    if (result.value) {
      var formData = {
        'id'        : id,
      }
      $.ajax({
        type: 'POST',
        url : 'inc/ajax.php?mstr=etiketsil',
        data: formData,
        dataType: 'JSON',
        success:function(data){
          if(data.durum == "success"){
            Swal.fire({
              position: 'center',
              icon: data.durum,
              title: data.mesaj,
              text: data.aciklama,
              showConfirmButton: false,
              timer: 1500
            });
              sayfayiyenile(1600);
          }
          else{
            Swal.fire(data.mesaj,data.aciklama,data.durum);
          }
        }
      });
    } else if (
      result.dismiss === Swal.DismissReason.cancel
    ){
      Swal.fire(
        'İptal Edildi',
        'Etiket Silme İşlemi Başlamadan Sonlandırıldı..',
        'info'
      )
    }
  });
}
/******************************************/
/*       Etiket  Group İşlemleri          */
/******************************************/
function etiketgrupislem(id,islem){
  var formData = {
    'tgid'     : id,
    'islem'     : islem,
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=etiketgrupislem',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      $(".modal-info").html(data.modal).modal('show');
      $('.chosen-select').chosen({width: "100%"});
    }
  });
}
function etiketgrupbilgikaydet(id,islem){
  var formData = {
    'tgid'            : id,
    'islem'           : islem,
    'tgadi'           : $("input[name=tgadi]").val(),
    'grupetiketler'   : $("#grupetiketler").val(),
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=etiketgrupbilgikaydet',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      if(data.durum == "success"){
        Swal.fire({
          position: 'center',
          icon: data.durum,
          title: data.mesaj,
          text: data.aciklama,
          showConfirmButton: false,
          timer: 1500
        });
          sayfayiyenile(1600);

      }
      else{
        Swal.fire({icon: data.durum,title: data.mesaj,text: data.aciklama});
      }
    }
  });
}
function etiketgrupsil(id){
  Swal.fire({
    title : 'Silmek İstediğine Emin misin?',
    text  : "Silme İşlemi Sonunda, Gönderide Kullanılan Etiket Groupları Yeniden Ayarlanamlıdır...",
    icon  : 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Evet, Sil!',
    cancelButtonText: 'İptal Et!',
    reverseButtons: true
  }).then((result) => {
    if (result.value) {
      var formData = {
        'id'        : id,
      }
      $.ajax({
        type: 'POST',
        url : 'inc/ajax.php?mstr=etiketgrupsil',
        data: formData,
        dataType: 'JSON',
        success:function(data){
          if(data.durum == "success"){
            Swal.fire({
              position: 'center',
              icon: data.durum,
              title: data.mesaj,
              text: data.aciklama,
              showConfirmButton: false,
              timer: 1500
            });
              sayfayiyenile(1600);
          }
          else{
            Swal.fire(data.mesaj,data.aciklama,data.durum);
          }
        }
      });
    } else if (
      result.dismiss === Swal.DismissReason.cancel
    ){
      Swal.fire(
        'İptal Edildi',
        'Etiket Silme İşlemi Başlamadan Sonlandırıldı..',
        'info'
      )
    }
  });
}
/******************************************/
/*       Görüş İşlemleri                  */
/******************************************/
function gorusoku(id){
  var formData = {
    'id'        : id,
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=gorusoku',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      $(".modal-primary").html(data.modal).modal('show');
    }
  });
}
function gorusislem(id,islem){
  var formData = {
    'tesid'     : id,
    'islem'     : islem,
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=gorusislem',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      $(".modal-info").html(data.modal).modal('show');
      $('.chosen-select').chosen({width: "100%"});
    }
  });
}
function gorusbilgikaydet(id,islem){
  var formData = {
    'tesid'       : id,
    'islem'       : islem,
    'tesmenu'     : $("#tesmenu").val(),
    'tesbaslik'   : $("input[name=tesbaslik]").val(),
    'tesaidiyet'  : $("input[name=tesaidiyet]").val(),
    'testarih'    : $("input[name=testarih]").val(),
    'tesicerik'   : $("#tesicerik").val(),
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=gorusbilgikaydet',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      if(data.durum == "success"){
        Swal.fire({
          position: 'center',
          icon: data.durum,
          title: data.mesaj,
          text: data.aciklama,
          showConfirmButton: false,
          timer: 1500
        });
          sayfayiyenile(1600);

      }
      else{
        Swal.fire({icon: data.durum,title: data.mesaj,text: data.aciklama});
      }
    }
  });
}
function gorussil(id){

  Swal.fire({
    title : 'Silmek İstediğine Emin misin?',
    text  : "Silme İşlemi Geri Alınamaz. Silme İşleminde Görüşlerin Menu ve İmage Bağlantıları Silinmektedir...",
    icon  : 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Evet, Sil!',
    cancelButtonText: 'İptal Et!',
    reverseButtons: true
  }).then((result) => {
    if (result.value) {
      var formData = {
        'id'        : id,
      }
      $.ajax({
        type: 'POST',
        url : 'inc/ajax.php?mstr=gorussil',
        data: formData,
        dataType: 'JSON',
        success:function(data){
          if(data.durum == "success"){
            Swal.fire({
              position: 'center',
              icon: data.durum,
              title: data.mesaj,
              text: data.aciklama,
              showConfirmButton: false,
              timer: 1500
            });
              sayfayiyenile(1600);
          }
          else{
            Swal.fire(data.mesaj,data.aciklama,data.durum);
          }
        }
      });
    } else if (
      result.dismiss === Swal.DismissReason.cancel
    ){
      Swal.fire(
        'İptal Edildi',
        'Görüş Silme İşlemi Başlamadan Sonlandırıldı..',
        'info'
      )
    }
  });
}
/******************************************/
/*       Makale İşlemleri                 */
/******************************************/
function kategorilerigetir(){
  var formData = {
    'makalemenuid' : $("#makalemenu").val(),
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=makalekategorigetir',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      if(data.durum == "success"){

        $("#makalekategori").html(data.kategoriveri);

      }
      else{
        Swal.fire(data.mesaj,data.aciklama,data.durum);
      }
    }
  });
}
function makaleislem(id){
  var url;
  if(id == 0){
    url = '?m=makale/yenimakale/'+id;
  }
  if(id > 0){
    url = '?m=makale/makaleguncelle/'+id;
  }
  $(location).prop('href', url);
}
function makalebilgikaydet(postid){
  var url = '?m=makale/makaleguncelle/'+postid;
  var icerik_detay = CKEDITOR.instances.makaleicerik.getData();
  var formData = {
    'makalebaslik'    : $("input[name=makalebaslık]").val(),
    'makalealtbaslık' : $("input[name=makalealtbaslık]").val(),
    'makaleturu'      : $("#makaleturu").val(),
    'makalemenu'      : $("#makalemenu").val(),
    'makalekategori'  : $("#makalekategori").val(),
    'makalelink'      : $("input[name=makalelink]").val(),
    'makalesmalimage' : $("#makalesmalimage").val(),
    'makaleetiketler' : $("#makaleetiketler").val(),
    'makaleicerik'    : icerik_detay,
    'id'              : postid,
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=makalebilgikaydet',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      if(data.durum == "success"){
        Swal.fire({
          position: 'center',
          icon: data.durum,
          title: data.mesaj,
          text: data.aciklama,
          showConfirmButton: false,
          timer: 1600
        });
        setTimeout(function() {
          $(location).prop('href', url);
        }, 1600);
      }
      else{
        Swal.fire(data.mesaj,data.aciklama,data.durum);
      }
    }
  });
}
function makalesil(postid){
  Swal.fire({
    title : 'Silmek İstediğine Emin misin?',
    text  : "Silme İşlemi Geri Alınamaz. Silme İşlemi Sonunda Makaleye\
            Ait Resim,Etiket,Menu ve kategori Ayarları Silinecektir.\
            Silinen Ayarlara Ait Dosyalar Kendi Menülerinden Tamamen Kaldırılabilmektedir...",
    icon  : 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Evet, Sil!',
    cancelButtonText: 'İptal Et!',
    reverseButtons: true
  }).then((result) => {
    if (result.value) {
      var formData = {
        'id'        : postid,
      }
      $.ajax({
        type: 'POST',
        url : 'inc/ajax.php?mstr=makalesil',
        data: formData,
        dataType: 'JSON',
        success:function(data){
          if(data.durum == "success"){
            Swal.fire({
              position: 'center',
              icon: data.durum,
              title: data.mesaj,
              text: data.aciklama,
              showConfirmButton: false,
              timer: 1500
            });
              sayfayiyenile(1600);
          }
          else{
            Swal.fire(data.mesaj,data.aciklama,data.durum);
          }
        }
      });
    } else if (
      result.dismiss === Swal.DismissReason.cancel
    ){
      Swal.fire(
        'İptal Edildi',
        'Makale Silme İşlemi Başlamadan Sonlandırıldı..',
        'info'
      )
    }
  });
}

/******************************************/
/*       Kullanıcı İşlemleri              */
/******************************************/
function kullaniciislem(id,islem){
  var formData = {
    'userid'      : id,
    'islem'       : islem,
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=kullaniciislem',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      $(".modal-info").html(data.modal).modal('show');
      $('.chosen-select').chosen({width: "100%"});
      $(".chosen-select").chosenImage({disable_search_threshold: 10 });
      $('#btarih .input-group.date').datepicker({
     		todayBtn: "linked",
     		keyboardNavigation: false,
     		forceParse: false,
     		calendarWeeks: true,
     		autoclose: true,
        format: "dd-mm-yyyy",
        todayHighlight: true
     	});
    }
  });
}
function kullanicisbilgikaydet(id,islem){
  var cv = $.trim($("#usercv").val());
  var formData = {
    'id'              : id,
    'islem'           : islem,
    'username'        : $("input[name=username]").val(),
    'userrealname'    : $("input[name=userrealname]").val(),
    'userrealsurname' : $("input[name=userrealsurname]").val(),
    'usermail'        : $("input[name=usermail]").val(),
    'userphone'       : $("input[name=userphone]").val(),
    'userbtarih'      : $("input[name=userbtarih]").val(),
    'useryetki'       : $("#useryetki").val(),
    'usergender'      : $("#usergender").val(),
    'userstatus'      : $("#userstatus").val(),
    'useravatar'      : $("#useravatar").val(),
    'usercv'          : cv,
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=kullanicisbilgikaydet',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      if(data.durum == "success"){
        Swal.fire({
          position: 'center',
          icon: data.durum,
          title: data.mesaj,
          html: data.aciklama
        }).then((result) => {
          $(".modal-info").modal('hide');
          sayfayiyenile(200);
        });
      }
      else{
        Swal.fire(data.mesaj,data.aciklama,data.durum);
      }
    }
  });
}
function kullanicisil(userid){
  Swal.fire({
    title : 'Silmek İstediğine Emin misin?',
    text  : "Silme İşlemi Geri Alınamaz. Silme İşlemi Sonunda Kullanıcıya\
            Ait Yetki,durum ve avatar Ayarları Silinecektir.\
            Silinen Ayarlara Ait Dosyalar Kendi Menülerinden Tamamen Kaldırılabilmektedir...",
    icon  : 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Evet, Sil!',
    cancelButtonText: 'İptal Et!',
    reverseButtons: true
  }).then((result) => {
    if (result.value) {
      var formData = {
        'id'        : userid,
      }
      $.ajax({
        type: 'POST',
        url : 'inc/ajax.php?mstr=kullanicisil',
        data: formData,
        dataType: 'JSON',
        success:function(data){
          if(data.durum == "success"){
            Swal.fire({
              position: 'center',
              icon: data.durum,
              title: data.mesaj,
              html: data.aciklama
            }).then((result) => {
              $(".modal-info").modal('hide');
              sayfayiyenile(200);
            });
          }
          else{
            Swal.fire(data.mesaj,data.aciklama,data.durum);
          }
        }
      });
    } else if (
      result.dismiss === Swal.DismissReason.cancel
    ){
      Swal.fire(
        'İptal Edildi',
        'Kullanıcı Silme İşlemi Başlamadan Sonlandırıldı..',
        'info'
      )
    }
  });
}
function kullanicisifredegisformu(id){
  var formData = {
    'userid'      : id,
  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=kullanicisifredegisformu',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      $(".modal-info").html(data.modal).modal('show');
    }
  });
}
function kullanicisifrebilgikaydet(id){
  var formData = {
    'id'                    : id,
    'kullanicieskisifre'    : $("input[name=kullanicieskisifre]").val(),
    'kullanicisifre'        : $("input[name=kullanicisifre]").val(),
    'kullanicisifretekrar'  : $("input[name=kullanicisifretekrar]").val(),

  }
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=kullanicisifrebilgikaydet',
    data: formData,
    dataType: 'JSON',
    success:function(data){
      if(data.durum == "success"){
        Swal.fire({
          position: 'center',
          icon: data.durum,
          title: data.mesaj,
          html: data.aciklama
        }).then((result) => {
          $(".modal-info").modal('hide');
          url = 'login/login.php';
          $(location).prop('href', url);
        });
      }
      else{
        Swal.fire(data.mesaj,data.aciklama,data.durum);
      }
    }
  });
}
/******************************************/
/*       Media İşlemleri                  */
/******************************************/
function imageislem(){
  $.ajax({
    type: 'POST',
    url : 'inc/ajax.php?mstr=imageislem',
    dataType: 'JSON',
    success:function(data){
      $(".modal-info").html(data.modal).modal('show');
      $('.chosen-select').chosen({width: "100%"});
      $('#imagebilgileri').empty();
      var drEvent = $('.dropify').dropify();
      drEvent = drEvent.data('dropify');
      drEvent.resetPreview();
      drEvent.clearElement();
    }
  });
}
$("div").on('change', '#imageinput',function(e){
    $('#imagebilgileri').empty();
    var icerik      = '';
    var imageAdi    = e.target.files[0].name;
    var imageBoyutu = formatBytes(e.target.files[0].size);
    var imageTipi   =  e.target.files[0].type;

    icerik +='\
      <br><span>\
      <b class="text-muted">Dosya Adı :</b>\
      <b class="text-info">'+imageAdi+'</b></span><br><br><span>\
      <b class="text-muted">Dosya Boyutu :</b>\
      <b class="text-info">'+imageBoyutu+'</b></span><br><br><span>\
      <b class="text-muted">Dosya Tipi :</b>\
      <b class="text-info">'+imageTipi+'</b></span>\ ';
    $('#imagebilgileri').append(icerik);
  });
function imagekaydet(){
  if (window.File && window.FileReader && window.FileList && window.Blob){
    var form_data = new FormData();
    var imagegroup =  $("#imagegroup").val();

    var files = $('#imageinput')[0].files[0];
    form_data.append('file',files);
    form_data.append('imagegroup', imagegroup);
    console.log(form_data);
    if(files != undefined) {
      var fsize     = $('#imageinput')[0].files[0].size;
      var ftype     = $('#imageinput')[0].files[0].type;
      switch(ftype){
        case 'image/png':
        case 'image/jpeg':
        case 'image/jpg':
        break;
        default:
          swal.fire("Hata!","Desteklenmeyen Dosya Türü..!","error");
        return false;
      }
      if(fsize > 5242880) {
        swal("Dosya Boyutu Desteklenen Sınırın Üstünde!","Dosya Boyutu 5 Mb dan Büyük Olamaz","error");
  	    return false;
  	  }
      $.ajax({
        url: 'inc/ajax.php?mstr=imagekaydet',
        type: 'post',
        data: form_data,
        dataType: 'json',
        contentType: false,
        processData: false,
        cache: false,
        success: function (data) {
          if(data.durum == 'success'){
            Swal.fire({
              position: 'center',
              icon: data.durum,
              title: data.mesaj,
              html: data.aciklama
            }).then((result) => {
              $(".modal-info").modal('hide');
              url = '?m=media/image';
              $(location).prop('href', url);
            });
          }else{
            swal.fire(data.mesaj,data.aciklama,data.durum);
          }
        }
      });
    }else{
      swal.fire("Hata!","Tanımlanamayan Dosya!","error");
      return false;
    }
  }else{
    swal.fire("Browser Hatası!","Lütfen tarayıcınızı yükseltin, çünkü mevcut tarayıcınızda ihtiyacımız olan bazı yeni özellikler yok!","error");
    return false;
  }
}
function imagesil(imageid){
  Swal.fire({
    title : 'Silmek İstediğine Emin misin?',
    text  : "Silme İşlemi Geri Alınamaz. Silme İşlemi Sonunda İmage\
            Ait Tüm Ayarlar İleYüklenen İmage Dosyası Silinecektir.\
            Silinen Ayarlara Ait Dosyalar Kendi Menülerinden Tamamen Kaldırılabilmektedir...",
    icon  : 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Evet, Sil!',
    cancelButtonText: 'İptal Et!',
    reverseButtons: true
  }).then((result) => {
    if (result.value) {
      var formData = {
        'id'        : imageid,
      }
      $.ajax({
        type: 'POST',
        url : 'inc/ajax.php?mstr=imagesil',
        data: formData,
        dataType: 'JSON',
        success:function(data){
          if(data.durum == "success"){
            Swal.fire({
              position: 'center',
              icon: data.durum,
              title: data.mesaj,
              html: data.aciklama
            }).then((result) => {
              $(".modal-info").modal('hide');
              sayfayiyenile(200);
            });
          }
          else{
            Swal.fire(data.mesaj,data.aciklama,data.durum);
          }
        }
      });
    } else if (
      result.dismiss === Swal.DismissReason.cancel
    ){
      Swal.fire(
        'İptal Edildi',
        'İmage Silme İşlemi Başlamadan Sonlandırıldı..',
        'info'
      )
    }
  });
}
