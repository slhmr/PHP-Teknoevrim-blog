<?php
$masterforminfo.="AnaSayfa";
$masterbreadcome.="	<li><a href='#'>AnaSayfa</a> <span class='bread-slash'>/</span>";
$mastercontent.="Anasayfa içeriği burda olacak";

?>
