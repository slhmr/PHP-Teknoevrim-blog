<?php
$footer="
</div>
<div class='footer-copyright-area'>
  <div class='container-fluid'>
    <div class='row'>
      <div class='col-lg-12'>
        <div class='footer-copy-right'>
          <p>Copyright © 2020 <a href='#'>MavRoSoft</a> All rights reserved.</p>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- =============== jquery JS ===================== -->
<script src='".loginstyle."js/vendor/jquery-1.11.3.min.js'></script>

<!-- =============== bootstrap JS ===================== -->
<script src='".loginstyle."js/bootstrap.min.js'></script>

<!-- =============== wow JS ===================== -->
<script src='".loginstyle."js/wow.min.js'></script>

<!-- =============== price-slider JS ===================== -->
<script src='".loginstyle."js/jquery-price-slider.js'></script>

<!-- =============== meanmenu JS ===================== -->
<script src='".loginstyle."js/jquery.meanmenu.js'></script>

<!-- =============== owl.carousel JS ===================== -->
<script src='".loginstyle."js/owl.carousel.min.js'></script>

<!-- =============== sticky JS ===================== -->
<script src='".loginstyle."js/jquery.sticky.js'></script>

<!-- =============== scrollUp JS ===================== -->
<script src='".loginstyle."js/jquery.scrollUp.min.js'></script>

<!-- =============== mCustomScrollbar JS ===================== -->
<script src='".loginstyle."js/scrollbar/jquery.mCustomScrollbar.concat.min.js'></script>
<script src='".loginstyle."js/scrollbar/mCustomScrollbar-active.js'></script>

<!-- =============== metisMenu JS ===================== -->
<script src='".loginstyle."js/metisMenu/metisMenu.min.js'></script>
<script src='".loginstyle."js/metisMenu/metisMenu-active.js'></script>

<!-- =============== data table JS ===================== -->
<script src='".loginstyle."js/datatable/jquery.dataTables.min.js'></script>

<!-- =============== tab JS ===================== -->
<script src='".loginstyle."js/tab.js'></script>

<!-- =============== summernote JS ===================== -->
<script src='".loginstyle."js/summernote/summernote.min.js'></script>
<script src='".loginstyle."js/summernote/summernote-active.js'></script>

<!-- =============== icheck JS ===================== -->
<script src='".loginstyle."js/icheck/icheck.min.js'></script>
<script src='".loginstyle."js/icheck/icheck-active.js'></script>

<!-- =============== morrisjs JS ===================== -->
<script src='".loginstyle."js/morrisjs/raphael-min.js'></script>
<script src='".loginstyle."js/morrisjs/morris.js'></script>
<script src='".loginstyle."js/morrisjs/morris-active.js'></script>

<!-- =============== morrisjs JS ===================== -->
<script src='".loginstyle."js/sparkline/jquery.sparkline.min.js'></script>
<script src='".loginstyle."js/sparkline/jquery.charts-sparkline.js'></script>

<!-- =============== calendar JS ===================== -->
<script src='".loginstyle."js/calendar/moment.min.js'></script>
<script src='".loginstyle."js/calendar/fullcalendar.min.js'></script>
<script src='".loginstyle."js/calendar/fullcalendar-active.js'></script>

<!-- =============== datapicker JS ===================== -->
<script src='".loginstyle."js/datapicker/bootstrap-datepicker.js'></script>
<script src='".loginstyle."js/datapicker/datepicker-active.js'></script>

<!-- =============== plugins JS ===================== -->
<script src='".loginstyle."js/plugins.js'></script>

<!-- =============== main JS ===================== -->
<script src='".loginstyle."js/main.js'></script>

<!-- =============== login JS ===================== -->
<script src='".loginstyle."js/login.js'></script>

<!-- =============== sweetalert2 JS ===================== -->
<script src='".loginstyle."js/sweetalert2.all.min.js'></script>

<!-- =============== datapicker JS ===================== -->
<script src='".loginstyle."js/datapicker/bootstrap-datepicker.js'></script>
<script src='".loginstyle."js/datapicker/datepicker-active.js'></script>

<!-- =============== input-mask JS ===================== -->
<script src='".loginstyle."js/input-mask/jasny-bootstrap.min.js'></script>

<!-- =============== chosen JS ===================== -->
<script src='".loginstyle."js/chosen/chosen.jquery.js'></script>
<script src='".loginstyle."js/chosen/chosenImage.jquery.js'></script>
<script src='".loginstyle."js/chosen/chosen-active.js'></script>

<!-- =============== ckeditor ===================== -->
<script src='".loginstyle."plugins/ckeditor/ckeditor.js'></script>

<!-- =============== custom JS ===================== -->
<script src='".loginstyle."js/custom.js'></script>

<!-- =============== dropify JS ===================== -->
<script src='".loginstyle."plugins/dropify/dropify.js'></script>

<!-- ============== select2 JS ======================== -->
<link rel='stylesheet' href='".loginstyle."plugins/select2/js/select2.full.min.js'>

<!-- ============== select2 JS ======================== -->
<link rel='stylesheet' href='".loginstyle."plugins/powertip/jquery.powertip.js'>

<script>
  $('#etiketlerdatatable').DataTable({rowReorder:{selector: 'td:nth-child(2)'},responsive: true});
  $('#etiketgrupdatatable').DataTable({rowReorder:{selector: 'td:nth-child(2)'},responsive: true});
  $('#gorusdatatable').DataTable({rowReorder:{selector: 'td:nth-child(2)'},responsive: true});
  $('#kullanicilistesi').DataTable({rowReorder:{selector: 'td:nth-child(2)'},responsive: true});
  $('#imagelistesi').DataTable({rowReorder:{selector: 'td:nth-child(2)'},responsive: true});
  $('.chosen-select').chosen({width: '100%'});
  $('.chosen-select').chosenImage({disable_search_threshold: 10 });
  $('#summernote2').summernote({height: 200,});
   CKEDITOR.replace( 'makaleicerik' );
   $('.north-east-alt').powerTip({ placement: 'ne-alt'});
</script>
</body>

</html>";
print $footer;
?>
