<?php
require_once('../../inc/session.php');
$dbc = new user();
require_once("../../inc/functions.php");
$sayfa = clearData(isset($_GET["mstr"]) ? $_GET["mstr"] : "mstr");
$parametre = explode("/",$sayfa);

$kullanicibilgileri=$dbc->fetchline("*","users where user_id=:id",array("id"=>$_SESSION['user_sssn']));
$userid=$kullanicibilgileri['user_id'];
/************************************/
/*			Menu İşlemleri							*/
/************************************/
if($parametre[0] == "showcategori"){
	if(!ajaxRquestCheck()){
		 echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
    	$id	=	clearData($_POST['id']);
			$baslik=$dbc->fetchcell("menu_name","menus where menu_id='$id'");
    	$kategori=$dbc->fetchall("m.menu_name,c.cat_name,c.cat_link,c.cat_id","
        categories as c
        left join catmenu as cm on cm.cat_id=c.cat_id
				left join menus as m on m.menu_id=cm.menu_id
        where cm.menu_id=:menuid group by cat_name
      ",array("menuid"=>$id));
      $modal="
        <div class='modal-dialog'>
          <div class='modal-content'>
            <div class='modal-header header-color-modal bg-color-1'>
              <h4 class='modal-title'>$baslik Menusü Kategorileri</h4>
              <div class='modal-close-area modal-close-df'>
                <a class='close' data-dismiss='modal' href='#'><i class='fa fa-close'></i></a>
              </div>
            </div>
            <div class='modal-body'>
							<table class='table table-hover'>
								<thead>
									<tr>
										<th>ID</th>
										<th>Kategori Adı</th>
										<th>Kategori Link</th>
									</tr>
								</thead>
								<tbody>";
							if($kategori != null)foreach ($kategori as $value) {
								$modal.="
									<tr>
										<td>{$value['cat_id']}</td>
										<td>{$value['cat_name']}</td>
										<td>{$value['cat_link']}</td>
									</tr>";
							}else{
								$modal.="
									<tr>
										<td colspan='3' class='text-center text-danger font-bold'>Kayıtlı Veri Bulunmammaktadır...!</td>
									</tr>";
							}
							  $modal.="
								</tbody>
							</table>
            </div>
            <div class='modal-footer'>
              <a data-dismiss='modal' href='#'>Kapat</a>
            </div>
          </div>
        </div>";
    $data['durum']="success";
    $data['modal']=$modal;
  echo  Json_encode($data);
  }
}
if($parametre[0] == "menuedit"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id			=	clearData($_POST['id']);
		$islem	=	clearData($_POST['islem']);

		if($islem	==	1){
			$baslik	="MENU EKLEME FORMU";
			$button	="Kaydet";
			$menuname="";
			$menulink="";
			$menuid=0;
		}
		elseif($islem	==	2){
			$baslik	="MENU DÜZENLEME FORMU";
			$button	="Güncelle";
			$menubilgi=$dbc->fetchline("menu_name,menu_link","menus where menu_id=:menuid",array("menuid"=>$id));
			$menuname=$menubilgi['menu_name'];
			$menulink=$menubilgi['menu_link'];
			$menuid=$id;
		}
		else{
			$data['durum']="error";
			exit();
		}
		$modal="
			<div class='modal-dialog'>
				<div class='modal-content'>
					<div class='modal-header header-color-modal bg-color-2'>
						<h4 class='modal-title'>{$baslik}</h4>
						<div class='modal-close-area modal-close-df'>
							<a class='close' data-dismiss='modal' href='#'><i class='fa fa-close'></i></a>
						</div>
					</div>
					<div class='modal-body'>
						<div class='row'>
							<div class='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
								<div class='row'>
	                <div class='col-lg-5 col-md-5 col-sm-5 col-xs-12'>
                    <label class='login2 pull-right pull-right-pro'>Menu Adı</label>
	                </div>
	                <div class='col-lg-7 col-md-7 col-sm-7 col-xs-12'>
                    <input type='text' class='form-control' name='menuadi' value='$menuname'/>
	                </div>
		            </div>
							</div>
							<div class='col-lg-6 col-md-6 col-sm-6 col-xs-12'>
							<div class='row'>
								<div class='col-lg-5 col-md-5 col-sm-5 col-xs-12'>
									<label class='pull-right pull-right-pro'>Menu Link</label>
								</div>
								<div class='col-lg-7 col-md-7 col-sm-7 col-xs-12'>
									<input type='text' class='form-control' name='menulink' value='$menulink'/>
								</div>
							</div>
							</div>
						</div>
					</div>
					<div class='modal-footer'>
						<a class='Danger danger-color' data-dismiss='modal'>Kapat</a>
						<a class='Information Information-color mg-b-10' type='submit' onclick='bilgilerikaydet($menuid,$islem)'>{$button}</a>
					</div>
				</div>
			</div>";


		$data['modal']=$modal;
		echo  Json_encode($data);
	}
}
if($parametre[0] == "bilgilerikaydet"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id				=	clearData($_POST['id']);
		$islem		=	clearData($_POST['islem']);
		$menuadi	=	clearData($_POST['menuadi']);
		$menulink	=	clearData($_POST['menulink']);

		if(empty($menuadi)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Menu Adi Boş Bırakılmaz..";
			echo  Json_encode($data);
			exit();
		}
		if(empty($menulink)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Menu Link Boş Bırakılmaz..";
			echo  Json_encode($data);
			exit();
		}
		if($islem == 1){
			$menuekle=$dbc->sqladd("menus",array("menu_name"=>$menuadi,"menu_link"=>$menulink));
			if($menuekle > 0){
				$data['durum']="success";
				$data['mesaj']="İşlem Başarılı";
				$data['aciklama']="Menu Ekleme İşlemi Başarıyla Gerçekleştirildi..";
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Menu Eklme İşlemi Başarısız Oldu..";
			}

		}elseif ($islem == 2){
			$menuekle=$dbc->sqlupdate("menus",array("menu_name"=>$menuadi,"menu_link"=>$menulink),"menu_id='$id'");
			if($menuekle > 0 || $menuekle == 'YES'){
				$data['durum']="success";
				$data['mesaj']="İşlem Başarılı";
				$data['aciklama']="Menu Güncellme İşlemi Başarıyla Gerçekleştirildi..";
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Menu Güncelleme İşlemi Başarısız Oldu..";
			}
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Geçersiz İstek Gönderildi.";
		}
		echo  Json_encode($data);
	}
}
if($parametre[0] == "menusil"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id				=	clearData($_POST['id']);
		if($id > 0){
			$menusil=$dbc->sqldelete("menus","menu_id='$id'");
			if($menusil){
				$data['durum']="success";
				$data['mesaj']="İşlem Başarılı";
				$data['aciklama']="Menu Silme İşlemi Başarıyla Gerçekleştirildi..";
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="İşlem Başarısız..";
			}
		}
		echo  Json_encode($data);
	}
}
/************************************/
/*			Kategori İşlemleri					*/
/************************************/
if($parametre[0] == "kategoriislem"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id			=	clearData($_POST['catid']);
		$islem	=	clearData($_POST['islem']);
		if($islem	==	1){
			$baslik	="KATEGORİ EKLEME FORMU";
			$button	="Kaydet";
			$catname="";
			$catlink="";
			$menuid="";
			$catid=0;
		}
		elseif($islem	==	2){
			$baslik	="KATEGORİ DÜZENLEME FORMU";
			$button	="Güncelle";
			$catbilgi=$dbc->fetchline("c.cat_name,c.cat_link,cm.menu_id","
									categories as c
									left join catmenu as cm on cm.cat_id=c.cat_id
									where c.cat_id=:catid",array("catid"=>$id));
			$catname=$catbilgi['cat_name'];
			$catlink=$catbilgi['cat_link'];
			$menuid=$catbilgi['menu_id'];
			$catid=$id;
		}
		else{
			$data['durum']="error";
			exit();
		}
		$modal="
			<div class='modal-dialog'>
				<div class='modal-content'>
					<div class='modal-header header-color-modal bg-color-2'>
						<h4 class='modal-title'>{$baslik}</h4>
						<div class='modal-close-area modal-close-df'>
							<a class='close' data-dismiss='modal' href='#'><i class='fa fa-close'></i></a>
						</div>
					</div>
					<div class='modal-body'>
						<div class='row'>
							<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
								<div class='chosen-select-single'>
									<label>Menu Seçiniz</label>
									<select class='chosen-select' id='kategorimenu' tabindex='-1'>
										<option value='0' selected hidden >Menu Seciniz...</option>";
										$menubilgisicek=$dbc->fetchall("menu_id,menu_name","menus where 1 order by menu_name asc",array());
										if($menubilgisicek != null)foreach ($menubilgisicek as $value) {
											if($menuid == $value['menu_id']){$sec="selected";}else{$sec="";}
												$modal.="
											<option value='{$value['menu_id']}' $sec>{$value['menu_name']}</option>";
										}
										$modal.="
									</select>
								</div>
							</div>
							<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
								<div class='form-group-inner'>
									<label>Kategori Adı</label>
									<input type='text' class='form-control' name='catadi' value='$catname'/>
								</div>
							</div>
							<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
								<div class='form-group-inner'>
									<label>Kategori Link</label>
									<input type='text' class='form-control' name='catlink' value='$catlink'/>
								</div>
							</div>
						</div>
					</div>
					<div class='modal-footer'>
						<a class='Danger danger-color' data-dismiss='modal'>Kapat</a>
						<a class='Information Information-color mg-b-10' type='submit' onclick='kategoribilgilerikaydet($catid,$islem)'>{$button}</a>
					</div>
				</div>
			</div>";


		$data['modal']=$modal;
		echo  Json_encode($data);
	}
}
if($parametre[0] == "kategoribilgikaydet"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$catid			=	clearData($_POST['catid']);
		$islem			=	clearData($_POST['islem']);
		$catadi			=	clearData($_POST['catadi']);
		$catlink		=	clearData($_POST['catlink']);
		$catmenuid	=	clearData($_POST['catmenuid']);

		if(empty($catmenuid) || $catmenuid < 1){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Kategori İçin En Az Bir Menu Seçilmelidir..";
			echo  Json_encode($data);
			exit();
		}

		if(empty($catadi)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Kategori Adi Boş Bırakılmaz..";
			echo  Json_encode($data);
			exit();
		}
		if(empty($catlink)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Kategori Link Boş Bırakılmaz..";
			echo  Json_encode($data);
			exit();
		}
		if($islem == 1){
			$kategoriekle=$dbc->sqladd("categories",array("cat_name"=>$catadi,"cat_link"=>$catlink));
			if($kategoriekle > 0){
				$kategorimenuiliski=$dbc->sqladd("catmenu",array("menu_id"=>$catmenuid,"cat_id"=>$kategoriekle));
				if($kategorimenuiliski > 0 || $kategorimenuiliski == 'YES'){
					$data['durum']="success";
					$data['mesaj']="İşlem Başarılı";
					$data['aciklama']="Kategori Ekleme İşlemi Başarıyla Gerçekleştirildi..";
				}else{
					$data['durum']="error";
					$data['mesaj']="HATA.!";
					$data['aciklama']="Kategori Menu İlişkisi Kurulamadı..";
				}
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Kategori Eklme İşlemi Başarısız Oldu..";
			}

		}elseif ($islem == 2){
			$kategoriekle=$dbc->sqlupdate("categories",array("cat_name"=>$catadi,"cat_link"=>$catlink),"cat_id='$catid'");
			if($kategoriekle > 0 || 	$kategoriekle == 'YES'){
				$kategorimenuiliski=$dbc->sqlupdate("catmenu",array("menu_id"=>$catmenuid),"cat_id='$catid'");
				if($kategorimenuiliski > 0 || $kategorimenuiliski == 'YES'){
					$data['durum']="success";
					$data['mesaj']="İşlem Başarılı";
					$data['aciklama']="Kategori Güncelleme İşlemi Başarıyla Gerçekleştirildi..";
				}
				else{
					$data['durum']="error";
					$data['mesaj']="HATA.!";
					$data['aciklama']="Kategori Menu İlişkisi Güncellenemedi..";
				}
			}
			else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Kategori Güncelleme İşlemi Başarısız Oldu..";
			}
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Hatalı İşlem Gönderildi..";
		}
		echo  Json_encode($data);
	}
}
if($parametre[0] == "kategorisil"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id				=	clearData($_POST['id']);
		if($id > 0){
			$catsil=$dbc->sqldelete("categories","cat_id='$id'");
			if($catsil){
				$catmenusil=$dbc->sqldelete("catmenu","cat_id='$id'");
				if($catmenusil){
					$data['durum']="success";
					$data['mesaj']="İşlem Başarılı";
					$data['aciklama']="Kategori Silme İşlemi Başarıyla Gerçekleştirildi..";
				}else{
					$data['durum']="error";
					$data['mesaj']="HATA.!";
					$data['aciklama']="Kategori Menu İlişkisi Silinemedi..";
				}
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Kategori Silme İşlemi Başarısız..";
			}
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="İşlem Başarısız..";
		}
		echo  Json_encode($data);
	}
}
/************************************/
/*			Etiket İşlemleri   					*/
/************************************/
if($parametre[0] == "etiketislem"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id			=	clearData($_POST['tagid']);
		$islem	=	clearData($_POST['islem']);
		if($islem	==	1){
			$baslik	="ETİKET EKLEME FORMU";
			$button	="Kaydet";
			$tagname="";
		}
		elseif($islem	==	2){
			$baslik	="ETİKET DÜZENLEME FORMU";
			$button	="Güncelle";
			$tagbilgi=$dbc->fetchline("tag_name","
									tags
									where tag_id=:tagid",array("tagid"=>$id));
			$tagname=$tagbilgi['tag_name'];
		}
		else{
			$data['durum']="error";
			echo  Json_encode($data);
			exit();
		}
		$modal="
			<div class='modal-dialog'>
				<div class='modal-content'>
					<div class='modal-header header-color-modal bg-color-2'>
						<h4 class='modal-title'>{$baslik}</h4>
						<div class='modal-close-area modal-close-df'>
							<a class='close' data-dismiss='modal' href='#'><i class='fa fa-close'></i></a>
						</div>
					</div>
					<div class='modal-body'>
						<div class='row'>
							<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
								<div class='form-group-inner'>
									<label>Etiket Adı</label>
								</div>
							</div>
							<div class='col-lg-8 col-md-8 col-sm-8 col-xs-12'>
								<div class='form-group-inner'>
									<input type='text' class='form-control' name='tagadi' value='$tagname'/>
								</div>
							</div>
						</div>
					</div>
					<div class='modal-footer'>
						<a class='Danger danger-color' data-dismiss='modal'>Kapat</a>
						<a class='Information Information-color mg-b-10' type='submit' onclick='etiketbilgikaydet($id,$islem)'>{$button}</a>
					</div>
				</div>
			</div>";


		$data['modal']=$modal;
		echo  Json_encode($data);
	}
}
if($parametre[0] == "etiketbilgikaydet"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$tagid			=	clearData($_POST['tagid']);
		$islem			=	clearData($_POST['islem']);
		$tagadi			=	clearData($_POST['tagadi']);

		if(empty($tagadi)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Etiket Adi Boş Bırakılmaz..";
			echo  Json_encode($data);
			exit();
		}

		if($islem == 1){
			$etiketekle=$dbc->sqladd("tags",array("tag_name"=>$tagadi));
			if($etiketekle > 0){
				$data['durum']="success";
				$data['mesaj']="İşlem Başarılı";
				$data['aciklama']="Etiket Ekleme İşlemi Başarıyla Gerçekleştirildi..";
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Etiket Eklme İşlemi Başarısız Oldu..";
			}

		}elseif ($islem == 2){
			$etiketekle=$dbc->sqlupdate("tags",array("tag_name"=>$tagadi),"tag_id='$tagid'");
			if($etiketekle > 0 || $etiketekle == 'YES'){
					$data['durum']="success";
					$data['mesaj']="İşlem Başarılı";
					$data['aciklama']="Etiket Güncelleme İşlemi Başarıyla Gerçekleştirildi..";
			}
			else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Etiket Güncelleme İşlemi Başarısız Oldu..";
			}
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Hatalı İşlem Gönderildi..";
		}
		echo  Json_encode($data);
	}
}
if($parametre[0] == "etiketsil"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id	=	clearData($_POST['id']);
		if($id > 0){
			$tagsil=$dbc->sqldelete("tags","tag_id='$id'");
			$taggrupsil=$dbc->sqldelete("tagroupsettings","tag_id='$id'");
			if($tagsil && $taggrupsil){
				$data['durum']="success";
				$data['mesaj']="İşlem Başarılı";
				$data['aciklama']="Etiket Silme İşlemi Başarıyla Gerçekleştirildi..";
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Etiket Silme İşlemi Başarısız..";
			}
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="İşlem Başarısız..";
		}
		echo  Json_encode($data);
	}
}
/************************************/
/*			Etiket İşlemleri   					*/
/************************************/
if($parametre[0] == "etiketgrupislem"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id			=	clearData($_POST['tgid']);
		$islem	=	clearData($_POST['islem']);
		if($islem	==	1){
			$baslik	="ETİKET GRUBU EKLEME FORMU";
			$button	="Kaydet";
			$tgname="";
		}
		elseif($islem	==	2){
			$baslik	="ETİKET GRUBU DÜZENLEME FORMU";
			$button	="Güncelle";
			$tgbilgi=$dbc->fetchline("tg_name","
									taggroups
									where tg_id=:tgid",array("tgid"=>$id));
			$tgname=$tgbilgi['tg_name'];
		}
		elseif($islem	==	3){
			$baslik	="ETİKET GRUBU ETİKET EKLEME VE ÇIKARTMA FORMU";
			$button	="Kaydet";
		}
		else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Hatalı Parametre...";
			echo  Json_encode($data);
			exit();
		}
		$modal="
			<div class='modal-dialog'>
				<div class='modal-content'>
					<div class='modal-header header-color-modal bg-color-2'>
						<h4 class='modal-title'>{$baslik}</h4>
						<div class='modal-close-area modal-close-df'>
							<a class='close' data-dismiss='modal' href='#'><i class='fa fa-close'></i></a>
						</div>
					</div>
					<div class='modal-body'>
						<div class='row'>
							<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
								<div class='form-group-inner'>
									<label>Etiket Grup Adı</label>
								</div>
							</div>
							<div class='col-lg-8 col-md-8 col-sm-8 col-xs-12'>";
							if($islem == 1 || $islem == 2){
								$modal .="
									<div class='form-group-inner'>
										<input type='text' class='form-control' name='tgadi' value='$tgname'/>
									</div>";
							}else{
								$modal .="
									<div class='chosen-select-single text-left'>
										<select class='form-control chosen-select' multiple id='grupetiketler'>";
												$etiketbilgicek=$dbc->fetchall("tag_id,tag_name","tags where 1 order by tag_name asc",array());
											if($etiketbilgicek != null)foreach ($etiketbilgicek as $value) {
												$tagid=$value['tag_id'];
												$kontrol=$dbc->fetchcell("tag_id","tagroupsettings where tg_id=:tg and tag_id=:tagid",array('tg' =>$id,'tagid' =>$tagid));
												if($kontrol != null){$sec='selected';}else{$sec='';}
													$modal.="
												<option value='{$tagid}' $sec>{$value['tag_name']}</option>";
											}
											$modal.="
										</select>
									</div>";
							}
							$modal .="
							</div>
						</div>
					</div>
					<div class='modal-footer'>
						<a class='Danger danger-color' data-dismiss='modal'>Kapat</a>
						<a class='Information Information-color mg-b-10' type='submit' onclick='etiketgrupbilgikaydet($id,$islem)'>{$button}</a>
					</div>
				</div>
			</div>";


		$data['modal']=$modal;
		echo  Json_encode($data);
	}
}
if($parametre[0] == "etiketgrupbilgikaydet"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$tgid			 			=	clearData($_POST['tgid']);
		$islem					=	clearData($_POST['islem']);
		if($islem == 1 || $islem == 2){
			$tgadi					=	clearData($_POST['tgadi']);
			if(empty($tgadi)){
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Etiket Grup Adi Boş Bırakılmaz..";
				echo  Json_encode($data);
				exit();
			}
		}else{
			$grupetiketler	=	clearData($_POST['grupetiketler']);
		}
		$hata						= 0;


		if($islem == 1){
			$etiketgrupekle=$dbc->sqladd("taggroups",array("tg_name"=>$tgadi));
			if($etiketgrupekle > 0){
				$data['durum']="success";
				$data['mesaj']="İşlem Başarılı";
				$data['aciklama']="Etiket Grup Ekleme İşlemi Başarıyla Gerçekleştirildi..";
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Etiket Grup Eklme İşlemi Başarısız Oldu..";
			}

		}elseif ($islem == 2){
			$etiketekle=$dbc->sqlupdate("taggroups",array("tg_name"=>$tgadi),"tg_id='$tgid'");
			if($etiketekle > 0 || $etiketekle == 'YES'){
					$data['durum']="success";
					$data['mesaj']="İşlem Başarılı";
					$data['aciklama']="Etiket Grup Güncelleme İşlemi Başarıyla Gerçekleştirildi..";
			}
			else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Etiket Grup Güncelleme İşlemi Başarısız Oldu..";
			}
		}elseif ($islem == 3){
			$kontrol=count($grupetiketler);
			$grupetiketsil=$dbc->sqldelete("tagroupsettings","tg_id='$tgid'");
			if($kontrol > 0){
				foreach ($grupetiketler as $value) {
					$makleetiketekle=$dbc->sqladd("tagroupsettings",
						array("tg_id"=>$tgid,"tag_id"=>$value));
					if($makleetiketekle != "YES"){
						$hata++;
					}
				}
				if($hata < 1){
					$data['durum']="success";
					$data['mesaj']="İşlem Başarılı.";
					$data['aciklama']="Etiketler Başarıyla Gruba Eklendi...";
				}else{
					$data['durum']="error";
					$data['mesaj']="HATA.!";
					$data['aciklama']="Etiketler Gruba Eklenemedi...";
				}
			}
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Hatalı İşlem Gönderildi..";
		}
		echo  Json_encode($data);
	}
}
if($parametre[0] == "etiketgrupsil"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id	=	clearData($_POST['id']);
		if($id > 0){
			$tgsil=$dbc->sqldelete("taggroups","tg_id='$id'");
			if($tgsil){
				$kontrol=$dbc->fetchall("tg_id","
										tagroupsettings
										where tg_id=:tgid",array("tgid"=>$id));
				if(count($kontrol) > 0){
					$tgayarsil=$dbc->sqldelete("tagroupsettings","tg_id='$id'");
					if($tgayarsil){
						$data['durum']="success";
						$data['mesaj']="İşlem Başarılı";
						$data['aciklama']="Etiket Grup Silme İşlemi Başarıyla Gerçekleştirildi..";
					}else{
						$data['durum']="error";
						$data['mesaj']="HATA.!";
						$data['aciklama']="Etiket Grup Ayarları Silme İşlemi Başarısız..";
					}
				}else{
					$data['durum']="success";
					$data['mesaj']="İşlem Başarılı";
					$data['aciklama']="Etiket Grup Silme İşlemi Başarıyla Gerçekleştirildi..";
				}
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Etiket Grup Silme İşlemi Başarısız..";
			}
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="İşlem Başarısız..";
		}
		echo  Json_encode($data);
	}
}

/************************************/
/*			Görüş İşlemleri   					*/
/************************************/
if($parametre[0] == "gorusoku"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id	=	clearData($_POST['id']);
		if($id > 0){
			$gorusquery=$dbc->fetchline("
		      t.tes_id,t.tes_title,t.tes_content,t.tes_name,t.tes_date,t.tes_addtime,
		      t.tes_updatetime,m.menu_name","
		    testimonials as t
		    left join testimonialsettings as ts on ts.tes_id=t.tes_id
		    left join menus as m on m.menu_id=ts.menu_id
				where t.tes_id=:tesid",array("tesid"=>$id));
			$modal="
				<div class='modal-dialog'>
					<div class='modal-content'>
						<div class='modal-header header-color-modal bg-color-1'>
							<h4 class='modal-title'>{$gorusquery['tes_title']}</h4>
							<div class='modal-close-area modal-close-df'>
								<a class='close' data-dismiss='modal' href='#'><i class='fa fa-close'></i></a>
							</div>
						</div>
						<div class='modal-body'>
							<div class='testimonial-details'>
								 {$gorusquery['tes_content']}
							</div>
						</div>
						<div class='modal-footer'>
							<a class='Danger danger-color' data-dismiss='modal'>Kapat</a>
						</div>
					</div>
				</div>";
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="İşlem Başarısız..";
		}
		$data['modal']=$modal;
		echo  Json_encode($data);
	}
}
if($parametre[0] == "gorusislem"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id			=	clearData($_POST['tesid']);
		$islem	=	clearData($_POST['islem']);
		if($islem	==	1){
			$baslik	="GÖRÜŞ EKLEME FORMU";
			$button	="Kaydet";
			$tesbaslik	= "";
			$tesicerik	= "";
			$tesaidiyet	= "";
			$testarih		= "";
			$tesmenu		= "";
			$tesid 			= "";
		}
		elseif($islem	==	2){
			$baslik	="GÖRÜŞ DÜZENLEME FORMU";
			$button	="Güncelle";
			$tesquery=$dbc->fetchline("
		      t.tes_id,t.tes_title,t.tes_content,t.tes_name,t.tes_date,t.tes_addtime,
		      t.tes_updatetime,m.menu_id","
		    testimonials as t
		    left join testimonialsettings as ts on ts.tes_id=t.tes_id
		    left join menus as m on m.menu_id=ts.menu_id
		    where t.tes_id=:tesid order by t.tes_id asc",array("tesid"=>$id));

				$tesbaslik	= $tesquery['tes_title'];
				$tesicerik	= $tesquery['tes_content'];
				$tesaidiyet	= $tesquery['tes_name'];
				$testarih		= $tesquery['tes_date'];
				$tesmenu		= $tesquery['menu_id'];
				$tesid			= $id;
			}
			else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Hatalı İşlem...";
				echo  Json_encode($data);
				exit();
			}
			$modal="
				<div class='modal-dialog'>
					<div class='modal-content'>
						<div class='modal-header header-color-modal bg-color-2'>
							<h4 class='modal-title'>{$baslik}</h4>
							<div class='modal-close-area modal-close-df'>
								<a class='close' data-dismiss='modal' href='#'><i class='fa fa-close'></i></a>
							</div>
						</div>
						<div class='modal-body'>
							<div class='row'>
								<div class='col-lg-6 col-md-6 col-sm-6 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Menu Seçiniz</label>
										<select class='chosen-select' id='tesmenu' tabindex='-1'>
											<option value='' selected hidden >Menu Seciniz...</option>";
											$menubilgisicek=$dbc->fetchall("menu_id,menu_name","menus where 1 order by menu_name asc",array());
											if($menubilgisicek != null)foreach ($menubilgisicek as $value) {
												if($tesmenu == $value['menu_id']){$sec="selected";}else{$sec="";}
													$modal.="
												<option value='{$value['menu_id']}' $sec>{$value['menu_name']}</option>";
											}
											$modal.="
										</select>
									</div>
								</div>
								<div class='col-lg-6 col-md-6 col-sm-6 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Görüş Başlık</label>
										<input type='text' class='form-control' name='tesbaslik' value='$tesbaslik'/>
									</div>
								</div>
							</div>
							<div class='row'>
								<div class='col-lg-6 col-md-6 col-sm-6 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Görüş Aidiyet</label>
										<input type='text' class='form-control' name='tesaidiyet' value='$tesaidiyet'/>
									</div>
								</div>
								<div class='col-lg-6 col-md-6 col-sm-6 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Görüş Tarih</label>
										<div class='input-group date'>
                      <span class='input-group-addon'><i class='fa fa-calendar'></i></span>
                      <input type='text' name='testarih' class='form-control' value='$testarih'>
                    </div>
									</div>
								</div>
							</div>
							<div class='row'>
								<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Görüş İçerik</label>
										<textarea type='text' class='form-control' id='tesicerik' rows='4'>{$tesicerik}</textarea>
									</div>
								</div>
							</div>
						</div>
						<div class='modal-footer'>
							<a class='Danger danger-color' data-dismiss='modal'>Kapat</a>
							<a class='Information Information-color mg-b-10' type='submit' onclick='gorusbilgikaydet($id,$islem)'>{$button}</a>
						</div>
					</div>
				</div>";
		$data['modal']=$modal;
		echo  Json_encode($data);
	}
}
if($parametre[0] == "gorusbilgikaydet"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$tesid				=	clearData($_POST['tesid']);
		$islem				=	clearData($_POST['islem']);
		$tesmenu			=	clearData($_POST['tesmenu']);
		$tesbaslik		=	clearData($_POST['tesbaslik']);
		$tesaidiyet		=	clearData($_POST['tesaidiyet']);
		$testarih			=	clearData($_POST['testarih']);
		$tesicerik		=	clearData($_POST['tesicerik']);

		if(empty($tesmenu)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Görüşün Gösterileceği Menuyü Seçmediniz..";
			echo  Json_encode($data);
			exit();
		}
		if(empty($tesbaslik)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Görüş Başlığı Boş Bırakılamaz..";
			echo  Json_encode($data);
			exit();
		}
		if(empty($tesaidiyet)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Görüş Aidiyet Boş Bırakılamaz..";
			echo  Json_encode($data);
			exit();
		}
		if(empty($testarih)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Görüş Tarih Boş Bırakılamaz..";
			echo  Json_encode($data);
			exit();
		}
		if(empty($tesicerik)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Görüş İçerik Boş Bırakılamaz..";
			echo  Json_encode($data);
			exit();
		}

		if($islem == 1){
			$gorusekle=$dbc->sqladd("testimonials",
				array("tes_title"=>$tesbaslik,"tes_content"=>$tesicerik,"tes_name"=>$tesaidiyet,"tes_date"=>$testarih));
			if($gorusekle > 0){
				$gorusmenuiliskiekle=$dbc->sqladd("testimonialsettings",
					array("tes_id"=>$gorusekle,"menu_id"=>$tesmenu));
					if($gorusmenuiliskiekle > 0 || $gorusmenuiliskiekle == 'YES'){
						$data['durum']="success";
						$data['mesaj']="İşlem Başarılı";
						$data['aciklama']="Görüş Ekleme İşlemi Başarıyla Gerçekleştirildi..";
					}
					else{
						$data['durum']="error";
						$data['mesaj']="HATA.!";
						$data['aciklama']="Görüş Menu İlişkisi Kurulamadı..";
					}
			}
			else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Görüş Ekleme İşlemi Başarısız Oldu..";
			}
		}elseif ($islem == 2){
			$gorusguncelle=$dbc->sqlupdate("testimonials",
				array("tes_title"=>$tesbaslik,"tes_content"=>$tesicerik,"tes_name"=>$tesaidiyet,
				"tes_date"=>$testarih),"tes_id='$tesid'");
			if($gorusguncelle > 0){
				$gorusmenuiliskiguncelle=$dbc->sqlupdate("testimonialsettings",
					array("menu_id"=>$tesmenu),"tes_id='$tesid'");
					if($gorusmenuiliskiguncelle > 0 || $gorusmenuiliskiguncelle == 'YES'){
						$data['durum']="success";
						$data['mesaj']="İşlem Başarılı";
						$data['aciklama']="Görüş Güncelleme İşlemi Başarıyla Gerçekleştirildi..";
					}
					else{
						$data['durum']="error";
						$data['mesaj']="HATA.!";
						$data['aciklama']="Görüş Menu İlişkisi Güncellenemedi..";
					}
			}
			else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Görüş Güncelleme İşlemi Başarısız Oldu..";
			}
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Hatalı İşlem Gönderildi..";
		}
		echo  Json_encode($data);
	}
}
if($parametre[0] == "gorussil"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id	=	clearData($_POST['id']);
		if($id > 0){
			$tessil=$dbc->sqldelete("testimonials","tes_id='$id'");
			if($tessil){
				$tesmenuiliskisil=$dbc->sqldelete("testimonialsettings","tes_id='$id'");
				if($tesmenuiliskisil){
					$data['durum']="success";
					$data['mesaj']="İşlem Başarılı";
					$data['aciklama']="Görüş Silme İşlemi Başarıyla Gerçekleştirildi..";
				}else{
					$data['durum']="error";
					$data['mesaj']="HATA.!";
					$data['aciklama']="Görüş Menu İlişki Silme İşlemi Başarısız..";
				}
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Görüş Silme İşlemi Başarısız..";
			}
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="İşlem Başarısız..";
		}
		echo  Json_encode($data);
	}
}
/************************************/
/*			Makale İşlemleri   					*/
/************************************/
if($parametre[0] == "makalekategorigetir"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id	=	clearData($_POST['makalemenuid']);
		$kategoribilgicek=$dbc->fetchall("c.cat_id,c.cat_name","
		catmenu as cm
		left join categories as c on c.cat_id=cm.cat_id
		where cm.menu_id=:menuid",array("menuid"=>$id));

		$data['kategoriveri']="<option value='0'>Kategori Seçiniz..</option>";

		if($kategoribilgicek != null)foreach($kategoribilgicek as $value){
			$data['kategoriveri'].="<option value='{$value['cat_id']}'>{$value['cat_name']}</option>";
		}

		$data['durum']="success";
		echo  Json_encode($data);
	}
}
if($parametre[0] == "makalebilgikaydet"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id								= clearData($_POST['id']);
		$makalebaslik			=	clearData($_POST['makalebaslik']);
		$makalealtbaslık	=	clearData($_POST['makalealtbaslık']);
		$makaleturu				=	clearData($_POST['makaleturu']);
		$makalemenu				=	clearData($_POST['makalemenu']);
		$makalekategori		=	clearData($_POST['makalekategori']);
		$makalelink				=	clearData($_POST['makalelink']);
		$makalesmalimage	=	clearData($_POST['makalesmalimage']);
		$makaleetiketler	=	clearData($_POST['makaleetiketler']);
		$makaleicerik			=	$_POST['makaleicerik'];
		if(empty($makalekategori)){$makalekategori=null;}

		if(empty($makalebaslik)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Makale Başlığı Boş Bırakılamaz..";
			echo  Json_encode($data);
			exit();
		}
		if(empty($makaleturu)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Makale Türünü Seçmediniz..";
			echo  Json_encode($data);
			exit();
		}
		if(empty($makalemenu)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Makale Menu Seçimi Yapmadınız..";
			echo  Json_encode($data);
			exit();
		}
		if($makaleturu == 5 && empty($makalelink)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Video Türünde Link Kısmı Boş Bırakılamaz..";
			echo  Json_encode($data);
			exit();
		}
		if($id == 0){
			$hata = 0;
			$makaleekle=$dbc->sqladd("posts",
				array("post_title"=>$makalebaslik,"post_subtitle"=>$makalealtbaslık,
				"post_link"=>$makalelink,"post_content"=>$makaleicerik));
			if($makaleekle > 0){
				$makaleayar=$dbc->sqladd("postsettings",
					array("post_id"=>$makaleekle,"type_id"=>$makaleturu,
					"menu_id"=>$makalemenu,"cat_id"=>$makalekategori,"user_id"=>$userid));
				if($makaleayar > 0 || $makaleayar == "YES" ){
					$postsmalimageadd=$dbc->sqladd("postimage",
						array("post_id"=>$makaleekle,"im_id"=>$makalesmalimage));
						if($postsmalimageadd != 'YES'){
							$hata++;
						}
					if(!empty($makaleetiketler))foreach ($makaleetiketler as $value) {
						$makleetiketekle=$dbc->sqladd("posttags",
							array("post_id"=>$makaleekle,"tg_id"=>$value));
						if($makleetiketekle != "YES"){
							$hata++;
						}
					}
					if($hata <1){
						$data['durum']="success";
						$data['mesaj']="İşlem Başarılı";
						$data['aciklama']="Makale Ekleme İşlemi Başarıyla Gerçekleştirildi..";
					}else{
						$data['durum']="error";
						$data['mesaj']="HATA.!";
						$data['aciklama']="Seçilen etiketler Makaleye Bağlanamadı..";
					}
				}else{
					$data['durum']="error";
					$data['mesaj']="HATA.!";
					$data['aciklama']="Makale Ayarları Oluşturulamadı..";
				}
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Makale Ekleme işlemi Başarısız..";
			}
		}elseif($id > 0){
			$hata = 0;
			$makaleguncelle=$dbc->sqlupdate("posts",
				array("post_title"=>$makalebaslik,"post_subtitle"=>$makalealtbaslık,
				"post_link"=>$makalelink,"post_content"=>$makaleicerik),"post_id='$id'");
			if($makaleguncelle > 0 || $makaleguncelle == "YES"){
				$makaleayar=$dbc->sqlupdate("postsettings",
					array("type_id"=>$makaleturu,"menu_id"=>$makalemenu,"cat_id"=>$makalekategori,
					"user_id"=>$userid),"post_id='$id'");
				if($makaleayar > 0 || $makaleayar == "YES"){
					$postsmalimageadd=$dbc->sqlupdate("postimage",
						array("im_id"=>$makalesmalimage),"post_id='$id'");
						if($postsmalimageadd != 'YES'){
							$hata++;
						}
						$temizle=$dbc->sqldelete("posttags","post_id='$id'");
					if(!empty($makaleetiketler))foreach ($makaleetiketler as $value) {
						$makleetiketekle=$dbc->sqladd("posttags",
						array("post_id"=>$id,"tg_id"=>$value));
						if($makleetiketekle != "YES"){
							$hata++;
						}
					}
					if($hata <1){
						$data['durum']="success";
						$data['mesaj']="İşlem Başarılı";
						$data['aciklama']="Makale Güncelleme İşlemi Başarıyla Gerçekleştirildi..";
					}else{
						$data['durum']="error";
						$data['mesaj']="HATA.!";
						$data['aciklama']="Seçilen Etiketler Makaleye Bağlanamadı..";
					}
				}else{
					$data['durum']="error";
					$data['mesaj']="HATA.!";
					$data['aciklama']="Makale Ayarları Güncellenemedi..";
				}
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Makale Güncelleme işlemi Başarısız..";
			}
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Hatalı İşlem Gönderildi..";
		}

		echo  Json_encode($data);
	}
}
if($parametre[0] == "makalesil"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id	=	clearData($_POST['id']);
		if($id > 0){
			$makalesil=$dbc->sqldelete("posts","post_id='$id'");
			if($makalesil){
				$makaleayarlarisil=$dbc->sqldelete("postsettings","post_id='$id'");
				if($makaleayarlarisil){
					$makaleetiketsil=$dbc->sqldelete("posttags","post_id='$id'");
					$makaleimagesil=$dbc->sqldelete("postimage","post_id='$id'");
					$data['durum']="success";
					$data['mesaj']="İşlem Başarılı";
					$data['aciklama']="Makale Silme İşlemi Başarıyla Gerçekleştirildi..";
				}else{
					$data['durum']="error";
					$data['mesaj']="HATA.!";
					$data['aciklama']="Makale Ayarları Silme İşlemi Başarısız..";
				}
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Makale Bilgileri Silme İşlemi Başarısız..";
			}
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="İşlem Başarısız..";
		}
		echo  Json_encode($data);
	}
}
/************************************/
/*			Kullanıcı İşlemleri   			*/
/************************************/
if($parametre[0] == "kullaniciislem"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id			=	clearData($_POST['userid']);
		$islem	=	clearData($_POST['islem']);
		if($islem	==	1){
			$baslik	="KULLANICI EKLEME FORMU";
			$button	="Kaydet";
			$username					= "";
			$userrealname			= "";
			$userrealsurname	= "";
			$useremail				= "";
			$usercv						= "";
			$userphone				= "";
			$usergender				= "";
			$userbtarih				= "";
			$userimid					= "";
			$authorityid			= "";
			$userstatus				= "";

		}
		elseif($islem	==	2){
			$baslik	="KULLANICI DÜZENLEME FORMU";
			$button	="Güncelle";
			$kullanicibilgi=$dbc->fetchline("
			    u.user_id,u.user_name,u.user_realname,u.user_realsurname,u.user_email,
			    us.user_status,us.authority_id,u.user_cv,u.user_phone,u.user_gender,
					user_btarih,us.user_im_id","
		    users as u
		    left join usersettings as us on  us.user_id=u.user_id
				where u.user_id='$id'
		    order by user_id asc");

				$username					= $kullanicibilgi['user_name'];
				$userrealname			= $kullanicibilgi['user_realname'];
				$userrealsurname	= $kullanicibilgi['user_realsurname'];
				$useremail				= $kullanicibilgi['user_email'];
				$usercv						= $kullanicibilgi['user_cv'];
				$userphone				= $kullanicibilgi['user_phone'];
				$usergender				= $kullanicibilgi['user_gender'];
				$userbtarih				= $kullanicibilgi['user_btarih'];
				$userimid					= $kullanicibilgi['user_im_id'];
				$authorityid			= $kullanicibilgi['authority_id'];
				$userstatus				= $kullanicibilgi['user_status'];

			}
			else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Hatalı İşlem...";
				echo  Json_encode($data);
				exit();
			}
			if($usergender == 1){$sec1="selected";}else{$sec1="";}
			if($usergender == 2){$sec2="selected";}else{$sec2="";}
			if($userstatus == 1){$sec3="selected";}else{$sec3="";}
			if($userstatus == 2){$sec4="selected";}else{$sec4="";}
			$modal="
				<div class='modal-dialog'>
					<div class='modal-content'>
						<div class='modal-header header-color-modal bg-color-2'>
							<h4 class='modal-title'>{$baslik}</h4>
							<div class='modal-close-area modal-close-df'>
								<a class='close' data-dismiss='modal' href='#'><i class='fa fa-close'></i></a>
							</div>
						</div>
						<div class='modal-body'>
							<div class='row'>
								<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Kullanıcı Adı</label>
										<input type='text' class='form-control' name='username' value='$username'/>
									</div>
								</div>
								<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Adı</label>
										<input type='text' class='form-control' name='userrealname' value='$userrealname'/>
									</div>
								</div>
								<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Soayadı</label>
										<input type='text' class='form-control' name='userrealsurname' value='$userrealsurname'/>
									</div>
								</div>
							</div>
							<div class='row'>
								<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 text-left'>
									<div class='form-group'>
										<label>E-Mail</label>
										<input type='text' class='form-control' name='usermail' value='$useremail'/>
									</div>
								</div>
								<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Telefon</label>
										<input type='text' class='form-control' name='userphone' value='$userphone'/>
									</div>
								</div>
								<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 text-left'>
									<div class='form-group data-custon-pick' id='btarih'>
										<label>Doğum Tarihi</label>
										<div class='input-group date'>
												<span class='input-group-addon'><i class='fa fa-calendar'></i></span>
												<input type='text' class='form-control' name='userbtarih' value='$userbtarih'>
										</div>
									</div>
								</div>
							</div>
							<div class='row'>
								<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Yetki Seviyesi</label>
										<select class='chosen-select' id='useryetki' tabindex='-1'>
											<option value='' selected hidden >Seciniz...</option>";
											$yetkibilgisicek=$dbc->fetchall("authority_id,authority","userauthorities where 1
																												order by authority asc",array());
											if($yetkibilgisicek != null)foreach ($yetkibilgisicek as $value) {
												if($authorityid == $value['authority_id']){$sec="selected";}else{$sec="";}
													$modal.="
												<option value='{$value['authority_id']}' $sec>{$value['authority']}</option>";
											}
											$modal.="
										</select>
									</div>
								</div>
								<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Cinsiyeti</label>
										<select class='chosen-select' id='usergender' tabindex='-1'>
											<option value='' selected hidden >Seciniz...</option>
											<option value='1' $sec1>Erkek</option>
											<option value='2' $sec2>Kadın</option>
										</select>
									</div>
								</div>
								<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Durumu</label>
										<select class='chosen-select' id='userstatus' tabindex='-1'>
											<option value='' selected hidden >Seciniz...</option>
											<option value='1' $sec3>Aktif</option>
											<option value='2' $sec4>Pasif</option>
										</select>
									</div>
								</div>
							</div>
							<div class='row'>
								<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Avatar</label>
										<select class='chosen-select' id='useravatar' tabindex='-1'>
											<option value='0' selected hidden >Seciniz...</option>";
											$avatarbilgisicek=$dbc->fetchall("i.im_id,i.im_path,i.im_name","
												images as i
												left join imagesettings as ims on ims.im_id=i.im_id
												where ims.type_id='1' order by i.im_name asc",array());
											if($avatarbilgisicek != null)foreach ($avatarbilgisicek as $value) {
													$modal.="
												<option value='{$value['im_id']}' data-img-src='../{$value['im_path']}/{$value['im_name']}'>{$value['im_name']}</option>";
											}
											$modal.="
										</select>
									</div>
								</div>
								<div class='col-lg-8 col-md-8 col-sm-8 col-xs-12 text-left'>
									<div class='form-group'>
										<label>Kullanıcı Hakkında Bilgi</label>
                    <textarea type='text' id='usercv' class='form-control'>
											$usercv
										</textarea>
									</div>
								</div>
							</div>
						</div>
						<div class='modal-footer'>
							<a class='Danger danger-color' data-dismiss='modal'>Kapat</a>
							<a class='Information Information-color mg-b-10' type='submit' onclick='kullanicisbilgikaydet($id,$islem)'>{$button}</a>
						</div>
					</div>
				</div>";
		$data['modal']=$modal;
		echo  Json_encode($data);
	}
}
if($parametre[0] == "kullanicisbilgikaydet"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id              = clearData($_POST['id']);
    $islem           = clearData($_POST['islem']);
    $username        = clearData($_POST['username']);
    $userrealname    = clearData($_POST['userrealname']);
		$userrealsurname = clearData($_POST['userrealsurname']);
		$usermail        = clearData($_POST['usermail']);
		$userphone       = clearData($_POST['userphone']);
		$userbtarih      = date('Y-m-d',strtotime(clearData($_POST['userbtarih'])));
		$useryetki       = clearData($_POST['useryetki']);
		$usergender      = clearData($_POST['usergender']);
		$userstatus      = clearData($_POST['userstatus']);
		$useravatar      = clearData($_POST['useravatar']);
		$usercv          = clearData($_POST['usercv']);

		if(empty($username)){$data['durum']="error";$data['mesaj']="HATA.!";$data['aciklama']="Kullanıcı Adı Boş Bırakılmaz..";echo  Json_encode($data);exit();}
		if(empty($userrealname)){$data['durum']="error";$data['mesaj']="HATA.!";$data['aciklama']="Adı Boş Bırakılmaz..";echo  Json_encode($data);exit();}
		if(empty($usermail)){$data['durum']="error";$data['mesaj']="HATA.!";$data['aciklama']="E-Mail Boş Bırakılmaz..";echo  Json_encode($data);exit();}
		if(empty($useryetki)){$data['durum']="error";$data['mesaj']="HATA.!";$data['aciklama']="Kullanıcı Kullanıcı Yetki Seviyesi Boş Bırakılamaz..";echo  Json_encode($data);exit();}
		if(empty($userstatus)){$data['durum']="error";$data['mesaj']="HATA.!";$data['aciklama']="KullanıcıDurumu Boş Bırakılmaz..";echo  Json_encode($data);exit();}
		if($useravatar == 0){$useravatar=NULL;}
		if($islem == 1){
			$sifre=createPass($username);
			$kullaniciekle=$dbc->sqladd("users",
				array("user_name"=>$username,"user_pass"=>$sifre,"user_realname"=>$userrealname,
					"user_realsurname"=>$userrealsurname,"user_email"=>$usermail,"user_phone"=>$userphone,
					"user_btarih"=>$userbtarih,"user_cv"=>$usercv,"user_gender"=>$usergender));

			if($kullaniciekle > 0){
				$kullaniciayarlari=$dbc->sqladd("usersettings",
					array("user_id"=>$kullaniciekle,"authority_id"=>$useryetki,"user_status"=>$userstatus,
						"user_im_id"=>$useravatar));
				if($kullaniciayarlari == 'YES'){
					$data['durum']="success";
					$data['mesaj']="İşlem Başarılı";
					$data['aciklama']="Kullanıcı Ekleme İşlemi Başarıyla Gerçekleştirildi.
														 Oluşturulan Kullanıcının İçin.<br/><center><b>$username</b></center><br/>Şifre Olarak Tanımlanmıştır";
				}else{
					$data['durum']="error";
					$data['mesaj']="HATA.!";
					$data['aciklama']="Kullanıcı Ayarları Ekleme İşlemi Başarısız Oldu..";
				}
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Kullanıcı Ekleme İşlemi Başarısız Oldu..";
			}

		}elseif ($islem == 2){
			$kullaniciguncelle=$dbc->sqlupdate("users",
				array("user_name"=>$username,"user_realname"=>$userrealname,"user_realsurname"=>$userrealsurname,
					"user_email"=>$usermail,"user_phone"=>$userphone,"user_btarih"=>$userbtarih,
					"user_cv"=>$usercv,"user_gender"=>$usergender),"user_id='$id'");

			if($kullaniciguncelle > 0 || $kullaniciguncelle == 'YES'){
				$kullaniciayarlari=$dbc->sqlupdate("usersettings",
					array("authority_id"=>$useryetki,"user_status"=>$userstatus,"user_im_id"=>$useravatar),
						"user_id='$id'");
				if($kullaniciayarlari > 0 || $kullaniciayarlari == 'YES'){
					$data['durum']="success";
					$data['mesaj']="İşlem Başarılı";
					$data['aciklama']="Kullanıcı Güncelleme İşlemi Başarıyla Gerçekleştirildi..";
				}else{
					$data['durum']="error";
					$data['mesaj']="HATA.!";
					$data['aciklama']="Kullanıcı Ayarları Güncelleme İşlemi Başarısız Oldu..";
				}
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="Kullanıcı Güncelleme İşlemi Başarısız Oldu..";
			}
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Hatalı İşlem Gönderildi..";
		}
		echo  Json_encode($data);
	}
}
if($parametre[0] == "kullanicisil"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id	=	clearData($_POST['id']);
		$kontrolyoneticisayisi=$dbc->fetchcell("count(u.user_id)","users as u
		left join usersettings as us on us.user_id=u.user_id
		 where us.authority_id='1'");
		 if($kontrolyoneticisayisi == 1){
			 $data['durum']="error";
			 $data['mesaj']="HATA.!";
			 $data['aciklama']=" Son Sistem Yöneticisi Silinemez..";
			 echo  Json_encode($data);
			 exit();
		 }else{
			 if($id > 0){
	 			$kullanicisil=$dbc->sqldelete("users","user_id='$id'");
	 			if($kullanicisil){
	 				$kullaniciayarlarisil=$dbc->sqldelete("usersettings","user_id='$id'");
	 				if($kullaniciayarlarisil){
	 					$data['durum']="success";
	 					$data['mesaj']="İşlem Başarılı";
	 					$data['aciklama']="Kullanıcı Silme İşlemi Başarıyla Gerçekleştirildi..";
	 				}else{
	 					$data['durum']="error";
	 					$data['mesaj']="HATA.!";
	 					$data['aciklama']="Kullanıcı Ayarları Silme İşlemi Başarısız..";
	 				}
	 			}else{
	 				$data['durum']="error";
	 				$data['mesaj']="HATA.!";
	 				$data['aciklama']="Kullanıcı Bilgileri Silme İşlemi Başarısız..";
	 			}
	 		}else{
	 			$data['durum']="error";
	 			$data['mesaj']="HATA.!";
	 			$data['aciklama']="İşlem Başarısız..";
	 		}
		 }
		echo  Json_encode($data);
	}
}
if($parametre[0] == "kullanicisifredegisformu"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id	=	clearData($_POST['userid']);
		$modal="
			<div class='modal-dialog'>
				<div class='modal-content'>
					<div class='modal-header header-color-modal bg-color-2'>
						<h4 class='modal-title'>KULLANICI ŞİFRE DEĞİŞTİRME FORMU</h4>
						<div class='modal-close-area modal-close-df'>
							<a class='close' data-dismiss='modal' href='#'><i class='fa fa-close'></i></a>
						</div>
					</div>
					<div class='modal-body'>
						<div class='row'>
							<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 text-left'>
								<div class='form-group'>
									<label>Eski Şifreniz</label>
									<input type='text' class='form-control' name='kullanicieskisifre'/>
								</div>
							</div>

							<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 text-left'>
								<div class='form-group'>
									<label>Yeni Şifre </label>
									<input type='text' class='form-control' name='kullanicisifre'/>
								</div>
							</div>

							<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12 text-left'>
								<div class='form-group'>
									<label>Yeni Şifre Tekrar</label>
									<input type='text' class='form-control' name='kullanicisifretekrar'/>
								</div>
							</div>
						</div>
					</div>
					<div class='modal-footer'>
					<a class='Danger danger-color' data-dismiss='modal'>Kapat</a>
					<a class='Information Information-color mg-b-10' type='submit' onclick='kullanicisifrebilgikaydet($id)'>Kaydet</a>
					</div>
				</div>
			</div>";
		$data['durum']="success";
		$data['modal']=$modal;
		echo  Json_encode($data);
	}
}
if($parametre[0] == "kullanicisifrebilgikaydet"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id										=	clearData($_POST['id']);
		$kullanicibilgicek=$dbc->fetchcell("user_pass","users where user_id=:id",array("id"=>$id));

		$kullanicieskisifre		=	clearData($_POST['kullanicieskisifre']);
    $kullanicisifre				=	clearData($_POST['kullanicisifre']);
    $kullanicisifretekrar	=	clearData($_POST['kullanicisifretekrar']);

		if(empty($kullanicieskisifre)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Şifre Değişikliği Yapabilmek İçin Eski Şifrenizi Girmeniz Gerekmektedir..";
			echo  Json_encode($data);
			exit();
		}
		if(!password_verify($kullanicieskisifre,$kullanicibilgicek)){
			$data['durum'] = "error";
			$data['mesaj'] = "Hatalı Eski Şifre !";
			$data['aciklama'] = "Eski Şifrenizi Hatalı Girdiniz..";
			echo  Json_encode($data);
			exit();
		}
		if(empty($kullanicieskisifre)){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Şifre Değişikliği Yapabilmek İçin Eski Şifrenizi Girmeniz Gerekmektedir..";
			echo  Json_encode($data);
			exit();
		}
		if($kullanicisifre != $kullanicisifretekrar){
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="Girilen Şifreler Birbiri ile eşlememktedir. Tekrar Deneyiniz..";
			echo  Json_encode($data);
			exit();
		}
		$sifreguncelle = $dbc->sqlupdate("users",array("user_pass" => createPass($kullanicisifre)),"user_id = '$id'");
		if($sifreguncelle > 0 || $sifreguncelle == 'YES'){
			$data['durum'] = "success";
			$data['mesaj'] = "İşlem Başarılı";
			$data['aciklama'] = "Şifre Değiştirme İşlemi Başarılı.. Giriş Sayfasına Yönlandirileceksiniz...";
			if($userid == $id ){
				session_destroy();
				echo  Json_encode($data);
				die();
			}else{
				echo  Json_encode($data);
			}
		}
	}
}
/************************************/
/*			Media İşlemleri   	    		*/
/************************************/
if($parametre[0] == "imageislem"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{

		$modal="
			<div class='modal-dialog'>
				<div class='modal-content'>
					<div class='modal-header header-color-modal bg-color-2'>
						<h4 class='modal-title'>İMAGE EKLEME FORMU</h4>
						<div class='modal-close-area modal-close-df'>
							<a class='close' data-dismiss='modal' href='#'><i class='fa fa-close'></i></a>
						</div>
					</div>
					<div class='modal-body'>
						<div class='row'>
							<div class='col-lg-6 col-md-6 col-sm-6 col-xs-12 text-left'>
								<div class='row'>
									<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left'>
										<div class='form-group'>
											<label>Türü</label>
											<select class='chosen-select' id='imagegroup' tabindex='-1'>
												<option value='0' selected hidden >Seciniz...</option>";
												$avatarbilgisicek=$dbc->fetchall("type_id,type","types where 1
																													order by type asc",array());
												if($avatarbilgisicek != null)foreach ($avatarbilgisicek as $value) {
														$modal.="
													<option value='{$value['type_id']}'>{$value['type']}</option>";
												}
												$modal.="
											</select>
										</div>
									</div>
								</div>
								<div class='row'>
									<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left'>
										<input type='file' id='imageinput' class='dropify'/>
									</div>
								</div>
							</div>
							<div class='col-lg-6 col-md-6 col-sm-6 col-xs-12 text-left'>
								<h4 class='modal-title'><span><b>Dosya Bilgileri</b></span></h4><hr/>
								<div class='digerislemler' id='imagebilgileri'></div>
							</div>
						</div><!--Row sonu -->
					</div>
					<div class='modal-footer'>
						<a class='Danger danger-color' data-dismiss='modal'>Kapat</a>
						<a class='Information Information-color mg-b-10' type='submit' onclick='imagekaydet()'>Kaydet</a>
					</div>
				</div>
			</div>";
		$data['modal']=$modal;
		echo  Json_encode($data);
		}
	}
if($parametre[0] == "imagekaydet"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
			$imagegrup=	clearData($_POST['imagegroup']);
			if($imagegrup == 0){$data['durum']="error";$data['mesaj']="HATA.!";$data['aciklama']="Resim Dosyasının Türünü Seçmediniz...";echo  Json_encode($data);exit();}
			switch ($imagegrup) {
				case 1:
					$max_en		= 145;
					$max_boy	= 145;
					break;
				case 2:
					$max_en		= 770;
					$max_boy	= 300;
					break;
				case 3:
					$max_en		= 270;
					$max_boy	= 120;
					break;
				case 4:
					$max_en		= 75;
					$max_boy	= 75;
					break;

				default:
					$max_en		= null;
					$max_boy	= null;
					break;
			}
			$filename = clearData($_FILES['file']['name']);
			$uzanti=substr($filename,-4,4);
      $fileSize = clearData($_FILES['file']['size']);
      $fileType = clearData($_FILES['file']['type']);

			$type=$dbc->fetchcell("type","types where type_id='$imagegrup'");
			$dosyayolu="files";
      $randsayi=rand(1,10000);


			if (!is_dir("../../".$dosyayolu."/".date("Y"))) {
        mkdir("../../".$dosyayolu."/".date("Y"), 0755, true);
			}
			$dosyapath=$dosyayolu."/".date("Y")."/";
      $dosyaadi=$type."-".date("Y").$randsayi.$uzanti;
			$imagekaydet=$dbc->sqladd("images",
				array("im_name"=>$dosyaadi,"im_size"=>$fileSize,"im_type"=>$fileType,
							"im_path"=>$dosyapath));
			 if($imagekaydet > 0){
				 $imagesetting=$dbc->sqladd("imagesettings",
				 	array("im_id"=>$imagekaydet,"user_id"=>$userid,"type_id"=>$imagegrup));
					if($imagesetting  == 'YES'){
						if(@move_uploaded_file($_FILES['file']['tmp_name'],"../../".$dosyapath . $dosyaadi)){
							ImageResize($max_en, $max_boy, "../../".$dosyapath . $dosyaadi, $fileType);
							$data["aciklama"]="Yüklediğiniz İmage Başarıyla ".date("Y")." İsimli İmage İçerisine $dosyaadi İsimli İmage Olarak Kaydedildi..";
              $data["mesaj"]="İmage Yükleme İşlemi Başarılı..!";
              $data["durum"]="success";
            }else{
              $data["aciklama"]="İşlem Başarısız";
              $data["mesaj"]="İmage Aktarımı Sırasında Hata Meydana GEldi..!";
              $data["durum"]="error";
            }
					}
					else{
						$data["aciklama"]="İşlem Başarısız";
            $data["mesaj"]="İmage Ayarları Oluşturulamadı..!";
            $data["durum"]="error";
					}
			 }
			 else{
				$data["aciklama"]="İşlem Başarısız";
        $data["mesaj"]="İmage Ekleme İşlemi Başarısız..!";
        $data["durum"]="error";
			 }
			echo  Json_encode($data);
		}
	}
if($parametre[0] == "imagesil"){
	if(!ajaxRquestCheck()){
		echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	}
  else{
		$id	=	clearData($_POST['id']);
		$silinecekdosya=$dbc->fetchline("im_name,im_path","images where im_id='$id'");
		$imagename=$silinecekdosya['im_name'];
		$impath=$silinecekdosya['im_path'];
	 	if($id > 0){
			$immagesil=$dbc->sqldelete("images","im_id='$id'");
			if($immagesil){
				$imageayarlarisil=$dbc->sqldelete("imagesettings","im_id='$id'");
				if($imageayarlarisil){
					$imagepostkontrol=$dbc->fetchall("post_id","postimage where im_id='$id'");
					if($imagepostkontrol != null && count($imagepostkontrol) > 0){
						$imageayarlarisil=$dbc->sqldelete("postimage","im_id='$id'");
					}
					$imageusersettings=$dbc->fetchall("user_im_id","usersettings where user_im_id='$id'");
					if($imageusersettings != null && count($imageusersettings) > 0){
						$imageayarlarisil=$dbc->sqlupdate("usersettings",array("user_im_id"=>null),"user_im_id='$id'");
					}
					@unlink("../../".$impath."/".$imagename);;
					$data['durum']="success";
					$data['mesaj']="İşlem Başarılı";
					$data['aciklama']="İmage Silme İşlemi Başarıyla Gerçekleştirildi..";
				}else{
					$data['durum']="error";
					$data['mesaj']="HATA.!";
					$data['aciklama']="İmage Ayarları Silme İşlemi Başarısız..";
				}
			}else{
				$data['durum']="error";
				$data['mesaj']="HATA.!";
				$data['aciklama']="İmage Bilgileri Silme İşlemi Başarısız..";
			}
		}else{
			$data['durum']="error";
			$data['mesaj']="HATA.!";
			$data['aciklama']="İşlem Başarısız..";
		}
		echo Json_encode($data);
	}
}





?>
