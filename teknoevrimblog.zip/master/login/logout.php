<?php
	session_start();
	unset($_SESSION['user_sssn']);
	if(session_destroy())
	{
		header("Location: ../../?pg=anaSayfa");
	}
?>
