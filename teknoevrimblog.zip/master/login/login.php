<?php
require_once("../../inc/default.php");
$login=
	"<!doctype html>
	<html class='no-js' lang='en'>

	<head>
	    <meta charset='utf-8'>
	    <meta http-equiv='x-ua-compatible' content='ie=edge'>
	    <title>TeknoEvrim Yönetim Paneli </title>
	    <meta name='description' content=''>
	    <meta name='viewport' content='width=device-width, initial-scale=1'>
	    <!-- favicon
			============================================ -->
	    <link rel='shortcut icon' type='image/x-icon' href='../".loginstyle."img/favicon.ico'>
	    <!-- Google Fonts
			============================================ -->
	    <link href='https://fonts.googleapis.com/css?family=Play:400,700' rel='stylesheet'>
	    <!-- Bootstrap CSS
			============================================ -->
	    <link rel='stylesheet' href='../".loginstyle."css/bootstrap.min.css'>
	    <!-- Bootstrap CSS
			============================================ -->
	    <link rel='stylesheet' href='../".loginstyle."css/font-awesome.min.css'>
	    <!-- owl.carousel CSS
			============================================ -->
	    <link rel='stylesheet' href='../".loginstyle."css/owl.carousel.css'>
	    <link rel='stylesheet' href='../".loginstyle."css/owl.theme.css'>
	    <link rel='stylesheet' href='../".loginstyle."css/owl.transitions.css'>
	    <!-- animate CSS
			============================================ -->
	    <link rel='stylesheet' href='../".loginstyle."css/animate.css'>
	    <!-- normalize CSS
			============================================ -->
	    <link rel='stylesheet' href='../".loginstyle."css/normalize.css'>
	    <!-- main CSS
			============================================ -->
	    <link rel='stylesheet' href='../".loginstyle."css/main.css'>
	    <!-- morrisjs CSS
			============================================ -->
	    <link rel='stylesheet' href='../".loginstyle."css/morrisjs/morris.css'>
	    <!-- mCustomScrollbar CSS
			============================================ -->
	    <link rel='stylesheet' href='../".loginstyle."css/scrollbar/jquery.mCustomScrollbar.min.css'>
	    <!-- metisMenu CSS
			============================================ -->
	    <link rel='stylesheet' href='../".loginstyle."css/metisMenu/metisMenu.min.css'>
	    <link rel='stylesheet' href='../".loginstyle."css/metisMenu/metisMenu-vertical.css'>
	    <!-- calendar CSS
			============================================ -->
	    <link rel='stylesheet' href='../".loginstyle."css/calendar/fullcalendar.min.css'>
	    <link rel='stylesheet' href='../".loginstyle."css/calendar/fullcalendar.print.min.css'>
	    <!-- forms CSS
			============================================ -->
	    <link rel='stylesheet' href='../".loginstyle."css/form/all-type-forms.css'>
	    <!-- style CSS
			============================================ -->
	    <link rel='stylesheet' href='../".loginstyle."css/style.css'>
	    <!-- responsive CSS
			============================================ -->
	    <link rel='stylesheet' href='../".loginstyle."css/responsive.css'>
			<!-- ============== sweetalert2 CSS ======================== -->
	    <link rel='stylesheet' href='../".loginstyle."css/sweetalert2.min.css'>
	    <!-- modernizr JS
			============================================ -->
	    <script src='../".loginstyle."js/vendor/modernizr-2.8.3.min.js'></script>
	</head>

	<body>
    <div class='container-fluid'>
      <div class='row mg-t-100'>
        <div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'></div>
        <div class='col-md-4 col-md-4 col-sm-4 col-xs-12'>
          <div class='text-center m-b-md custom-login'>
            <h3>MASTER KULLANICI GİRİŞİ</h3>
            <a href='../../index.php' class='btn'>Teknoevrim.net</a>
          </div>
          <div class='hpanel'>
            <div class='panel-body'>
              <div class='form-group'>
                <label class='control-label' >Kullanıcı Adı</label>
                <input type='text' name='kullaniciadi' class='form-control kullaniciadi' placeholder='Kullanıcı Adı' title='Master Kullanıcı Adını Giriniz.'  >

              </div>
              <div class='form-group'>
                <label class='control-label'>Kullanıcı Şifre</label>
                <input type='password' name='kullanicisifre' class='form-control kullanicisifre' title='Şifrenizi Giriniz' placeholder='******' >

              </div>
              <div class='checkbox login-checkbox kullanicisifre text-center'>
								<button type='button' class='btn btn-custon-rounded-four btn-primary btn-lg loginbtn' onclick='girisyap()'>
									<i class='fa fa-key adminpro-informatio' aria-hidden='true'></i>
									 Giriş Yap
								</button>
              </div>
            </div>
        </div>
				<div class'row'>
					 <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center'> ".footerbilgi."</div>
				</div>
				<div class='row'>
					<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
						<div class='result'></div>
					</div>
				</div>
      </div>
    </div>

	    <!-- jquery
			============================================ -->
	    <script src='../".loginstyle."js/vendor/jquery-1.11.3.min.js'></script>
	    <!-- bootstrap JS
			============================================ -->
	    <script src='../".loginstyle."js/bootstrap.min.js'></script>
	    <!-- wow JS
			============================================ -->
	    <script src='../".loginstyle."js/wow.min.js'></script>
	    <!-- price-slider JS
			============================================ -->
	    <script src='../".loginstyle."js/jquery-price-slider.js'></script>
			<!-- sweetalert2 JS
			============================================ -->
			<script src='../".loginstyle."js/sweetalert2.all.min.js'></script>

	    <!-- meanmenu JS
			============================================ -->
	    <script src='../".loginstyle."js/jquery.meanmenu.js'></script>
	    <!-- owl.carousel JS
			============================================ -->
	    <script src='../".loginstyle."js/owl.carousel.min.js'></script>
	    <!-- sticky JS
			============================================ -->
	    <script src='../".loginstyle."js/jquery.sticky.js'></script>
	    <!-- scrollUp JS
			============================================ -->
	    <script src='../".loginstyle."js/jquery.scrollUp.min.js'></script>
	    <!-- mCustomScrollbar JS
			============================================ -->
	    <script src='../".loginstyle."js/scrollbar/jquery.mCustomScrollbar.concat.min.js'></script>
	    <script src='../".loginstyle."js/scrollbar/mCustomScrollbar-active.js'></script>
	    <!-- metisMenu JS
			============================================ -->
	    <script src='../".loginstyle."js/metisMenu/metisMenu.min.js'></script>
	    <script src='../".loginstyle."js/metisMenu/metisMenu-active.js'></script>
	    <!-- tab JS
			============================================ -->
	    <script src='../".loginstyle."js/tab.js'></script>
	    <!-- icheck JS
			============================================ -->
	    <script src='../".loginstyle."js/icheck/icheck.min.js'></script>
	    <script src='../".loginstyle."js/icheck/icheck-active.js'></script>
	    <!-- plugins JS
			============================================ -->
	    <script src='../".loginstyle."js/plugins.js'></script>
	    <!-- main JS
			============================================ -->
	    <script src='../".loginstyle."js/main.js'></script>

			<!-- login JS
			============================================ -->
			<script src='../".loginstyle."js/login.js'></script>
	</body>

	</html>";
	print $login;

	?>
