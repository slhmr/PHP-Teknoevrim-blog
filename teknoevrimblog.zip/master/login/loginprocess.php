<?php
session_start();
require "../../inc/dbConnection.php";
require "../../inc/functions.php";

$login = new USER();

if(!ajaxRquestCheck()){
	echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
}
else{
	$kullaniciadi = clearData($_POST['kullaniciadi']);
	$kullanicisifre = clearData($_POST['kullanicisifre']);
	if($login->doLogin($kullaniciadi,$kullanicisifre)){
		 $data['durum']="success";
	}
	else{
		$data['durum']="
			<div class='alert alert-danger alert-mg-b alert-st-four alert-st-bg3' role='alert'>
				<i class='fa fa-times adminpro-danger-error admin-check-pro admin-check-pro-clr3' aria-hidden='true'></i>
				<p class='message-mg-rt'><strong>Hata!</strong> Giriş İşlemi Başarısız....</p>
			</div>";
		}
	 echo  Json_encode($data);
}

?>
