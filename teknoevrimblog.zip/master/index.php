<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
require_once("../inc/session.php");
$dbc = new user();
require_once("../inc/functions.php");
require_once("../inc/default.php");
require_once("../inc/modal.php");

if(isset($_SESSION['user_sssn']) ==''){
		header('location:login/login.php');
	}
  else{
		$kullanicibilgileri=$dbc->fetchline("*","users where user_id=:id",array("id"=>$_SESSION['user_sssn']));
		$userrealname=$kullanicibilgileri['user_realname'].$kullanicibilgileri['user_realsurname'];
		$userid=$kullanicibilgileri['user_id'];
		require_once("view/header.php");
		require_once("view/sidebar.php");

		$m = isset($_GET["m"]) ? $_GET["m"] : "m";
		$masterurl = explode("/",$m);

		if($masterurl[0] == "m" && !isset($masterurl[1])){
			echo "<script language='JavaScript'>window.location='?m=MasterAnaSayfa'</script>";exit();
		}

		switch ($masterurl[0]) {
			case  'menu'					:	require_once("islemler.php");	break;
	    case  'kategori'			: require_once("islemler.php");break;
			case  'etiket'				: require_once("islemler.php");break;
			case  'etiketgrup'		: require_once("islemler.php");break;
			case  'ozlusoz'					: require_once("islemler.php");break;
			case  'makale'				: require_once("islemler.php");break;
			case  'kullanicilar'	: require_once("islemler.php");break;
			case  'media'					: require_once("islemler.php");break;
			case 	'MasterAnaSayfa': require_once("islemler.php");break;
			default:break;
		}


	require_once("view/content.php");
  require_once("view/footer.php");
}
?>
