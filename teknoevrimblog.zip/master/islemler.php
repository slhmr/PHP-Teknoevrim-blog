<?php
if(isset($masterurl[0]) && $masterurl[0] == "MasterAnaSayfa" ){
  $masterforminfo.="TeknoEvrim Yönetim Paneli AnaSayfası";
  $masterbreadcome.="	<li><a href='#'>AnaSayfa</a> <span class='bread-slash'>";

  $online=count($dbc->fetchall("id","online where 1",array()));
  $uniqevisit=count($dbc->fetchall("id","visit where 1 group by ip",array()));
  $totalvisit=count($dbc->fetchall("id","visit where 1",array()));
  $weekvisit=count($dbc->fetchall("id","visit where YEARWEEK(time) = YEARWEEK(CURRENT_DATE)",array()));
  $totalpagevisit=count($dbc->fetchall("id","visit where page like '%anaSayfa%'",array()));

  $percenttotalpagevisit=$totalpagevisit/100*100;
  $percentvisit=$weekvisit/$weekvisit*100;
  $uniqepercentvisit=$uniqevisit/$totalvisit*100;


  $mastercontent.="
    <div class='container-fluid mg-t-100'>
      <div class='row text-center'>
        <div class='col-md-12'>
          <div class='row'>
            <div class='col-lg-3 col-md-3 col-sm-3 col-xs-12'>
              <div class='admin-content analysis-progrebar-ctn res-mg-t-30'>
                <h4 class='text-left text-uppercase'><b>Online</b></h4>
                <div class='row vertical-center-box vertical-center-box-tablet'>
                  <div class='text-left col-xs-3 mar-bot-15'>
                    <!--<label class='label bg-purple'>80% <i class='fa fa-level-up' aria-hidden='true'></i></label>-->
                  </div>
                  <div class='col-xs-9 cus-gh-hd-pro'>
                    <h2 class='text-right no-margin'>{$online}</h2>
                  </div>
                </div>
                <div class='progress progress-mini'>
                  <div style='width: ". $online/100*100 ."%' class='progress-bar bg-purple'></div>
                </div>
              </div>
            </div>
            <div class='col-lg-3 col-md-3 col-sm-3 col-xs-12'>
              <div class='admin-content analysis-progrebar-ctn res-mg-t-30'>
                <h4 class='text-left text-uppercase'><b>Benzersiz Ziyaretçi</b></h4>
                <div class='row vertical-center-box vertical-center-box-tablet'>
                  <div class='text-left col-xs-3 mar-bot-15'>
                    <!--<label class='label bg-blue'>50% <i class='fa fa-level-up' aria-hidden='true'></i></label>-->
                  </div>
                  <div class='col-xs-9 cus-gh-hd-pro'>
                    <h2 class='text-right no-margin'>{$uniqevisit}</h2>
                  </div>
                </div>
                <div class='progress progress-mini'>
                  <div style='width: {$uniqepercentvisit}%;' class='progress-bar bg-blue'></div>
                </div>
              </div>
            </div>
            <div class='col-lg-3 col-md-3 col-sm-3 col-xs-12'>
              <div class='admin-content analysis-progrebar-ctn res-mg-t-15'>
                <h4 class='text-left text-uppercase'><b>Toplam Ziyaretçi</b></h4>
                <div class='row vertical-center-box vertical-center-box-tablet'>
                  <div class='col-xs-3 mar-bot-15 text-left'>
                  </div>
                  <div class='col-xs-9 cus-gh-hd-pro'>
                    <h2 class='text-right no-margin'>{$totalvisit}</h2>
                  </div>
                </div>
                <div class='progress progress-mini'>
                  <div style='width: {$totalvisit}%;' class='progress-bar bg-green'></div>
                </div>
              </div>
            </div>
            <div class='col-lg-3 col-md-3 col-sm-3 col-xs-12' style='margin-bottom:1px;'>
              <div class='admin-content analysis-progrebar-ctn res-mg-t-30'>
                <h4 class='text-left text-uppercase'><b>Toplam Görüntüleme</b></h4>
                <div class='row vertical-center-box vertical-center-box-tablet'>
                  <div class='text-left col-xs-3 mar-bot-15'>
                    <!--<label class='label bg-red'>15% <i class='fa fa-level-down' aria-hidden='true'></i></label>-->
                  </div>
                  <div class='col-xs-9 cus-gh-hd-pro'>
                    <h2 class='text-right no-margin'>$totalpagevisit</h2>
                  </div>
                </div>
                <div class='progress progress-mini'>
                  <div style='width: {$percenttotalpagevisit}%;' class='progress-bar progress-bar-danger bg-red'></div>
                </div>
              </div>
            </div>
          </div>
          <div class='row'>
            <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
              <div class='sparkline12-list mg-b-15 mg-t-15'>
                <div class='table-responsive'>
                  <table id='etiketlerdatatable' class='table display' style='width:100%'>
                    <thead>
                      <tr>
                        <th>IP</th>
                        <th>İşletim Sistemi</th>
                        <th>Tarayıcı</th>
                        <th>Kıta</th>
                        <th>Ülke</th>
                        <th>Kodu</th>
                        <th>Şehir</th>
                        <th>Enlem</th>
                        <th>Boylam</th>
                        <th>Bölge</th>
                        <th>Referer</th>
                        <th>Sayfa</th>
                        <th>Tarih</th>
                      </tr>
                    </thead>
                    <tbody>";
                    $sorgu=$dbc->fetchall("*","visit order by id desc");
                  if($sorgu != null)foreach ($sorgu as $value) {
                    $mastercontent.="
                      <tr>
                        <td class='text-center'>{$value['ip']}</td>
                        <td class='text-center'>{$value['os']}</td>
                        <td class='text-center'>{$value['browser']}</td>
                        <td class='text-center'>{$value['continentName']}</td>
                        <td class='text-center'>{$value['countryName']}</td>
                        <td class='text-center'>{$value['countryCode']}</td>
                        <td class='text-center'>{$value['city']}</td>
                        <td class='text-center'>{$value['latitude']}</td>
                        <td class='text-center'>{$value['longitude']}</td>
                        <td class='text-center'>{$value['region']}</td>
                        <td>{$value['referer']}</td>
                        <td>{$value['page']}</td>
                        <td>".date("d-m-Y H:i:s",strtotime($value['time']))."</td>
                      </tr>";
                    }
                    $mastercontent.="
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>";
}
elseif(isset($masterurl[0]) && $masterurl[0] == "menu") {
  $masterforminfo.="Header Menu Ayarları Sayfası";
  $masterbreadcome.="	<li><a href='#'>AnaSayfa</a> <span class='bread-slash'> / </span>
                      <li><span class='bread-blod'>Header Menu</span>";
  $headermenus=$dbc->fetchall("*","menus group by menu_name order by menu_name asc");
  $mastercontent.="
      <div class='container-fluid'>
        <div class='row'>
          <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
            <div class='sparkline12-list mg-b-15 mg-t-15'>
              <div class='sparkline12-hd'>
                <div class='main-sparkline12-hd'>
                  <h1>Kayıtlı Menuler</h1>
                </div>
              </div>
              <button class='btn btn-sm btn-primary login-submit-cs mg-b-15' type='submit' onclick='menuislem(0,1)'>
                <i class='fa fa-pencil text-default'></i> Yeni Menu Ekle
              </button>
              <div class='table-responsive'>
                <table class='table table-hover  mg-t-15'>
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Menu Adı</th>
                      <th>Menu Link</th>
                      <th>Kategori Sayısı</th>
                      <th>Gönderi (Makale) Sayısı</th>
                      <th>Eklenme Tarihi</th>
                      <th>Güncellenme Tarihi</th>
                      <th>İşlemler</th>
                    </tr>
                  </thead>
                  <tbody>";
                if($headermenus != null)foreach ($headermenus as $value) {
                  $kategorisayisi=$dbc->fetchcell("count(cat_id)","catmenu where menu_id='{$value['menu_id']}'");
                  $gonderisayisi=$dbc->fetchcell("count(post_id)","postsettings where menu_id='{$value['menu_id']}'");
                  $mastercontent.="
                    <tr>
                      <td>{$value['menu_id']}</td>
                      <td>{$value['menu_name']}</td>
                      <td>{$value['menu_link']}</td>
                      <td class='text-center'><a href='#' onclick='showcategories({$value['menu_id']})'>{$kategorisayisi}</a></td>
                      <td class='text-center'>{$gonderisayisi}</td>
                      <td>".date("d-m-Y H:i:s",strtotime($value['menu_addtime']))."</td>
                      <td>".date("d-m-Y H:i:s",strtotime($value['menu_updatetime']))."</td>
                      <td>
                        <a href='#' title='Menu Güncelleme' onclick='menuislem({$value['menu_id']},2)'>
                          <i class='fa fa-edit text-info'></i>
                        </a>&nbsp;
                        <a href='#' title='Menu Silme' onclick='menusil({$value['menu_id']})'>
                          <i class='fa fa-trash text-danger'></i>
                        </a>
                      </td>
                    </tr>";
                  }
                  $mastercontent.="
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>";
}
elseif(isset($masterurl[0]) && $masterurl[0] == "kategori") {
  $masterforminfo.="Kategori Ayarları Sayfası";
  $masterbreadcome.="	<li><a href='#'>AnaSayfa</a> <span class='bread-slash'> / </span>
                       <li><span class='bread-blod'>Kategoriler</span>";
  $headermenus=$dbc->fetchall("m.menu_id,m.menu_name,c.cat_id,c.cat_name,c.cat_link,c.cat_addtime,c.cat_updatetime","
    categories as c
    left join catmenu as cm on cm.cat_id=c.cat_id
    left join menus as m on m.menu_id=cm.menu_id
    group by cat_name order by cat_name asc");
  $mastercontent.="
      <div class='container-fluid'>
        <div class='row'>
          <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
            <div class='sparkline12-list mg-b-15 mg-t-15'>
              <div class='sparkline12-hd'>
                <div class='main-sparkline12-hd'>
                  <h1>Kayıtlı Kategoriler</h1>
                </div>
              </div>
              <button class='btn btn-sm btn-primary login-submit-cs mg-b-15' type='submit' onclick='kategoriislem(0,1)'>
                <i class='fa fa-pencil text-default'></i> Yeni Katehori Ekle
              </button>
              <div class='table-responsive'>
                <table class='table table-hover  mg-t-15'>
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Kategori Adı</th>
                      <th>Kategori Link</th>
                      <th>Menu</th>
                      <th>Eklenme Tarihi</th>
                      <th>Güncellenme Tarihi</th>
                      <th>İşlemler</th>
                    </tr>
                  </thead>
                  <tbody>";
                if($headermenus != null)foreach ($headermenus as $value) {
                  $kategorisayisi=$dbc->fetchcell("count(cat_id)","catmenu where menu_id='{$value['menu_id']}'");
                  $mastercontent.="
                    <tr>
                      <td>{$value['cat_id']}</td>
                      <td>{$value['cat_name']}</td>
                      <td>{$value['cat_link']}</td>
                      <td>{$value['menu_name']}</td>
                      <td>".date("d-m-Y H:i:s",strtotime($value['cat_addtime']))."</td>
                      <td>".date("d-m-Y H:i:s",strtotime($value['cat_updatetime']))."</td>
                      <td>
                        <a href='#' title='kategori Güncelleme' onclick='kategoriislem({$value['cat_id']},2)'>
                          <i class='fa fa-edit text-info'></i>
                        </a>&nbsp;
                        <a href='#' title='kategori Silme' onclick='kategorisil({$value['cat_id']})'>
                          <i class='fa fa-trash text-danger'></i>
                        </a>
                      </td>
                    </tr>";
                  }
                  $mastercontent.="
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>";
}
elseif(isset($masterurl[0]) && $masterurl[0] == "etiket") {
  $masterforminfo.="Etiket Ayarları Sayfası";
  $masterbreadcome.="	<li><a href='#'>AnaSayfa</a> <span class='bread-slash'> / </span>
                      <li><span class='bread-blod'>Etiketler</span>";

  $tagsquery=$dbc->fetchall("
      t.tag_id,t.tag_name,t.tag_addtime,t.tag_updatetime,tg.tg_name","
    tags as t
    left join tagroupsettings as tgs on tgs.tag_id=t.tag_id
    left join taggroups as tg on tg.tg_id=tgs.tg_id
    where 1
    group by tag_name order by tag_name asc");
  $mastercontent.="
      <div class='container-fluid'>
        <div class='row'>
          <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
            <div class='sparkline12-list mg-b-15 mg-t-15'>
              <div class='sparkline12-hd'>
                <div class='main-sparkline12-hd'>
                  <h1>Kayıtlı Etiketler</h1>
                </div>
              </div>
              <button class='btn btn-sm btn-primary login-submit-cs mg-b-15' type='submit' onclick='etiketislem(0,1)'>
                <i class='fa fa-pencil text-default'></i> Yeni Etiket Ekle
              </button>
              <div class='table-responsive'>
                <table id='etiketlerdatatable' class='table display' style='width:100%'>
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Grubu</th>
                      <th>Etiket Adı</th>
                      <th>Eklenme Tarihi</th>
                      <th>Güncellenme Tarihi</th>
                      <th>İşlemler</th>
                    </tr>
                  </thead>
                  <tbody>";
                if($tagsquery != null)foreach ($tagsquery as $value) {
                  $mastercontent.="
                    <tr>
                      <td class='text-center'>{$value['tag_id']}</td>
                      <td class='text-center'>{$value['tg_name']}</td>
                      <td>{$value['tag_name']}</td>
                      <td>".date("d-m-Y H:i:s",strtotime($value['tag_addtime']))."</td>
                      <td>".date("d-m-Y H:i:s",strtotime($value['tag_updatetime']))."</td>
                      <td class='text-center'>
                        <a href='#' title='Etiket Güncelleme' onclick='etiketislem({$value['tag_id']},2)'>
                          <i class='fa fa-edit text-info'></i>
                        </a>&nbsp;
                        <a href='#' title='Etiket Silme' onclick='etiketsil({$value['tag_id']})'>
                          <i class='fa fa-trash text-danger'></i>
                        </a>
                      </td>
                    </tr>";
                  }
                  $mastercontent.="
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>";
}
elseif(isset($masterurl[0]) && $masterurl[0] == "etiketgrup") {
  $masterforminfo.="Etiket Ayarları Sayfası";
  $masterbreadcome.="	<li><a href='#'>AnaSayfa</a> <span class='bread-slash'> / </span>
                      <li><span class='bread-blod'>Etiketler</span>";

  $tagsquery=$dbc->fetchall("
      tg_id,tg_name,tg_addtime,tg_updatetime","
    taggroups
    group by tg_name order by tg_name asc");
  $mastercontent.="
      <div class='container-fluid'>
        <div class='row'>
          <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
            <div class='sparkline12-list mg-b-15 mg-t-15'>
              <div class='sparkline12-hd'>
                <div class='main-sparkline12-hd'>
                  <h1>Kayıtlı Etiket Grupları</h1>
                </div>
              </div>
              <button class='btn btn-sm btn-primary login-submit-cs mg-b-15' type='submit' onclick='etiketgrupislem(0,1)'>
                <i class='fa fa-pencil text-default'></i> Yeni Grup Ekle
              </button>
              <div class='table-responsive'>
                <table id='etiketgrupdatatable' class='table display' style='width:100%'>
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Group Adı</th>
                      <th>Eklenme Tarihi</th>
                      <th>Güncellenme Tarihi</th>
                      <th>İşlemler</th>
                    </tr>
                  </thead>
                  <tbody>";
                if($tagsquery != null)foreach ($tagsquery as $value) {
                  $mastercontent.="
                    <tr>
                      <td class='text-center'>{$value['tg_id']}</td>
                      <td>{$value['tg_name']}</td>
                      <td>".date("d-m-Y H:i:s",strtotime($value['tg_addtime']))."</td>
                      <td>".date("d-m-Y H:i:s",strtotime($value['tg_updatetime']))."</td>
                      <td class='text-center'>
                        <a href='#' title='Etiket Grubu Güncelleme' onclick='etiketgrupislem({$value['tg_id']},2)'>
                          <i class='fa fa-edit text-info'></i>
                        </a>&nbsp;&nbsp;
                        <a href='#' title='Etiket Ekleme' onclick='etiketgrupislem({$value['tg_id']},3)'>
                          <i class='fa fa-tags text-primary'></i>
                        </a>&nbsp;&nbsp;
                        <a href='#' title='Etiket Grubu Silme' onclick='etiketgrupsil({$value['tg_id']})'>
                          <i class='fa fa-trash text-danger'></i>
                        </a>
                      </td>
                    </tr>";
                  }
                  $mastercontent.="
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>";
}
elseif(isset($masterurl[0]) && $masterurl[0] == "ozlusoz") {
  $masterforminfo.="Görüş Ayarları Sayfası";
  $masterbreadcome.="	<li><a href='#'>AnaSayfa</a> <span class='bread-slash'> / </span>
                      <li><span class='bread-blod'>Görüşler</span>";

  $tesquery=$dbc->fetchall("
      t.tes_id,t.tes_title,t.tes_content,t.tes_name,t.tes_date,t.tes_addtime,
      t.tes_updatetime,m.menu_name","
    testimonials as t
    left join testimonialsettings as ts on ts.tes_id=t.tes_id
    left join menus as m on m.menu_id=ts.menu_id
    order by tes_id asc");
  $mastercontent.="
      <div class='container-fluid'>
        <div class='row'>
          <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
            <div class='sparkline12-list mg-b-15 mg-t-15'>
              <div class='sparkline12-hd'>
                <div class='main-sparkline12-hd'>
                  <h1>Kayıtlı Görüşler</h1>
                </div>
              </div>
              <button class='btn btn-sm btn-primary login-submit-cs mg-b-15' type='submit' onclick='gorusislem(0,1)'>
                <i class='fa fa-pencil text-default'></i> Yeni Görüş Ekle
              </button>
              <div class='table-responsive'>
                <table id='gorusdatatable' class='table display' style='width:100%'>
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Başlık</th>
                      <th>Aidiyet</th>
                      <th>Tarihi</th>
                      <th>Menu</th>
                      <th>İçerik</th>
                      <th>Eklenme Tarihi</th>
                      <th>Güncellenme Tarihi</th>
                      <th>İşlemler</th>
                    </tr>
                  </thead>
                  <tbody>";
                if($tesquery != null)foreach ($tesquery as $value) {
                  $mastercontent.="
                    <tr>
                      <td class='text-center'>{$value['tes_id']}</td>
                      <td>{$value['tes_title']}</td>
                      <td>{$value['tes_name']}</td>
                      <td>".date("d-m-Y",strtotime($value['tes_date']))."</td>
                      <td>{$value['menu_name']}</td>
                      <td>".split_words($value['tes_content'],15,"  [...]")."</td>
                      <td>".date("d-m-Y H:i:s",strtotime($value['tes_addtime']))."</td>
                      <td>".date("d-m-Y H:i:s",strtotime($value['tes_updatetime']))."</td>
                      <td class='text-center'>
                        <a href='#' title='Görüş Oku' onclick='gorusoku({$value['tes_id']})'>
                          <i class='fa fa-eye text-purple'></i>
                        </a>&nbsp;
                        <a href='#' title='Etiket Güncelleme' onclick='gorusislem({$value['tes_id']},2)'>
                          <i class='fa fa-edit text-info'></i>
                        </a>&nbsp;
                        <a href='#' title='Etiket Silme' onclick='gorussil({$value['tes_id']})'>
                          <i class='fa fa-trash text-danger'></i>
                        </a>
                      </td>
                    </tr>";
                  }
                  $mastercontent.="
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>";
}
elseif(isset($masterurl[0]) && $masterurl[0] == "makale") {
  if((isset($masterurl[1]) && $masterurl[1] == "yenimakale") || (isset($masterurl[1]) && $masterurl[1] == "makaleguncelle")) {
    $id=$masterurl[2];
    if($id == 0){
			$formbaslik="Yeni Makale Ekleme Formu";
      $breadlink="Yeni Makale";
			$buton="Bilgileri Kaydet";
			$baslik="";
			$sbaslik="";
			$link="";
			$postcontent="";
			$mid="";
			$cid="";
			$tid="";
      $imid="";
      $altkategori="";
		}
    if($id > 0){
			$formbaslik="Makale Güncelleme Formu";
      $breadlink="Makale Güncelle - $id";
			$buton="Bilgileri Güncelle";
			$postinfo=$dbc->fetchall("p.post_title,p.post_subtitle,p.post_link,p.post_content,
				m.menu_id,c.cat_id,ps.type_id,pi.im_id","
			posts as p
			left join postsettings as ps on ps.post_id=p.post_id
      left join postimage as pi on pi.post_id=p.post_id
      left join imagesettings as ims on ims.im_id=pi.im_id
			left join menus as m on m.menu_id=ps.menu_id
			left join categories as c on c.cat_id=ps.cat_id
			where p.post_id=:postid
			",array('postid' =>$id));
			if($postinfo != null)foreach ($postinfo as $value) {
				$baslik=$value['post_title'];
				$sbaslik=$value['post_subtitle'];
				$link=$value['post_link'];
				$postcontent=$value['post_content'];
				$mid=$value['menu_id'];
				$cid=$value['cat_id'];
				$tid=$value['type_id'];
        $imid=$value['im_id'];
			}
      $altkategorisorgu=$dbc->fetchcell("cat_name","categories where cat_id=:catid",array("catid" =>$cid));
      $altkategori="<option value='{$cid}'>{$altkategorisorgu}</option>";
		}

    $masterforminfo.=$formbaslik;
    $masterbreadcome.="	<li><a href='#'>AnaSayfa</a><span class='bread-slash'>&nbsp;/&nbsp;</span></li>
                        <li class='text-muted'>Makale İşlemleri<span class='bread-slash'>&nbsp;/&nbsp;</span></li>
                        <li  class='text-success'><span class='bread-blod'>$breadlink</span></li>";

    $mastercontent.="
      <div class='container-fluid'>
        <div class='row'>
          <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
            <div class='sparkline12-list mg-b-15 mg-t-15'>
              <div class='sparkline12-graph'>
                <div class='basic-login-form-ad'>
                  <div class='row'>
                    <div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
                      <div class='form-group-inner'>
                        <label class='control-label'>Makale Başlık &nbsp;<span class='text-megna'>*</span></label>
                        <input type='text' class='form-control' name='makalebaslık' value='$baslik'>
                      </div>
                    </div>
                    <div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
                      <div class='form-group-inner'>
                        <label class='control-label'>Makale Alt Başlık</label>
                        <input type='text' class='form-control' name='makalealtbaslık' value='$sbaslik'>
                      </div>
                    </div>
                    <div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
                      <div class='form-group'>
                        <label>Small İmage</label>
                        <select class='chosen-select makalesmalimage' id='makalesmalimage' tabindex='-1'>
                          <option value='0' selected hidden >Seciniz...</option>";
                          $imagebilgisicek=$dbc->fetchall("i.im_id,i.im_path,i.im_name","
                            images as i
                            left join imagesettings as ims on ims.im_id=i.im_id
                            where ims.type_id='3' order by i.im_name asc",array());
                          if($imagebilgisicek != null)foreach ($imagebilgisicek as $value) {
                            if($imid == $value['im_id']){$sec="selected";}else{$sec="";}
                              $mastercontent.="
                            <option value='{$value['im_id']}' data-img-src='../{$value['im_path']}/{$value['im_name']}' $sec>{$value['im_name']}</option>";
                          }
                          $mastercontent.="
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class='row'>
                    <div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
                      <div class='form-select-list text-left'>
                        <label>Makale Türü</label>
                        <select class='chosen-select' id='makaleturu' tabindex='-1'>
                          <option value='' selected hidden >Makale Türünü Seciniz...</option>";
                          $turbilgisicek=$dbc->fetchall("type_id,type_name","posttypes where 1 order by type_name asc",array());
                          if($turbilgisicek != null)foreach ($turbilgisicek as $value) {
                            if($tid == $value['type_id']){$sec="selected";}else{$sec="";}
                              $mastercontent.="
                            <option value='{$value['type_id']}' $sec>{$value['type_name']}</option>";
                          }
                          $mastercontent.="
                        </select>
                      </div>
                    </div>
                    <div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
                      <div class='form-select-list'>
                        <label class='control-label'>Makale Menu &nbsp;<span class='text-megna'>*</span></label>
                        <select class='form-control custom-select-lg' id='makalemenu' tabindex='-1' onchange='kategorilerigetir()'>
                          <option value='' selected hidden >Menu Seçiniz </option>";
                            $menubilgisicek=$dbc->fetchall("menu_id,menu_name","menus where 1 order by menu_name asc",array());
                          if($menubilgisicek != null)foreach ($menubilgisicek as $value) {
                            if($mid == $value['menu_id']){$sec="selected";}else{$sec="";}
                              $mastercontent.="
                            <option value='{$value['menu_id']}' $sec>{$value['menu_name']}</option>";
                          }
                          $mastercontent.="
                        </select>
                      </div>
                    </div>
                    <div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
                      <div class='form-select-list'>
                        <label class='control-label'>Makale Kategori</label>
                        <select class='form-control custom-select-lg' id='makalekategori' tabindex='-1' input-lg>
                          {$altkategori}
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class='row mg-t-25'>
                    <div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
                      <div class='form-group-inner'>
                        <label class='control-label'>Link&nbsp;<small class='text-megna'>Video İçin ID Giriniz</small></label>
                        <input type='text' class='form-control' name='makalelink' value='$link'>
                      </div>
                    </div>
                    <div class='col-lg-8 col-md-8 col-sm-8 col-xs-12'>
                      <div class='form-select-list text-left'>
                        <label class='control-label'>Etiketler</span></label>
                        <select class='form-control chosen-select' multiple id='makaleetiketler'>";
                            $etiketbilgicek=$dbc->fetchall("tg_id,tg_name","taggroups where 1 order by tg_name asc",array());
                          if($etiketbilgicek != null)foreach ($etiketbilgicek as $value) {
                            $tgid=$value['tg_id'];
                            $kontrol=$dbc->fetchcell("tg_id","posttags where post_id=:postid and tg_id=:tgid",array('postid' =>$id,'tgid' =>$tgid));
                            if($kontrol != null){$sec='selected';}else{$sec='';}
                              $mastercontent.="
                            <option value='{$tgid}' $sec>{$value['tg_name']}</option>";
                          }
                          $mastercontent.="
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class='row mg-t-25'>
                    <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                      <div class='form-group-inner'>
                        <label class='control-label'>Makale İçerik</label>
                        <textarea class='ckeditor' name='makaleicerik' id='makaleicerik'  rows='20' cols='80'>
                          $postcontent
                        </textarea>
                      </div>
                    </div>
                  </div>
                  <div class='row mg-t-25'>
                    <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                      <div class='login-horizental cancel-wp pull-right'>
                        <button class='btn btn-default waves-effect' onclick='sayfayiyenile(200)'>Sayfayı Yenile</button>
                        <button class='btn btn-primary waves-effect' onclick='makalebilgikaydet($id)'>$buton</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>";
  }
  if(isset($masterurl[1]) && $masterurl[1] == "listele") {
    $masterforminfo.="Makale Listeleme Sayfası";
    $masterbreadcome.="	<li><a href='#'>AnaSayfa</a><span class='bread-slash'>&nbsp;/&nbsp;</span></li>
                        <li class='text-muted'>Makale İşlemleri<span class='bread-slash'>&nbsp;/&nbsp;</span></li>
                        <li  class='text-success'><span class='bread-blod'>Makale Listele</span></li>";

    $makalequery=$dbc->fetchall("*","
      posts as p
      left join postsettings as ps on ps.post_id=p.post_id
      left join menus as m on m.menu_id=ps.menu_id
      left join categories as c on c.cat_id=ps.cat_id
      left join posttypes as pt on pt.type_id=ps.type_id
      left join users as u on u.user_id=ps.user_id
      where 1 order by p.post_id desc
      ");
    $mastercontent.="
        <div class='container-fluid'>
          <div class='row'>
            <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
              <div class='sparkline12-list mg-b-15 mg-t-15'>
                <div class='sparkline12-hd'>
                  <div class='main-sparkline12-hd'>
                    <h1>Kayıtlı Makaleler</h1>
                  </div>
                </div>
                <button class='btn btn-sm btn-primary login-submit-cs mg-t-15' type='submit' onclick='makaleislem(0)'>
                  <i class='fa fa-file-o text-default'><sup class='fa fa-plus'></sup></i> Yeni Makale Ekle
                </button>
                <div class='table-responsive mg-t-30'>
                  <table id='gorusdatatable' class='table display' style='width:100%'>
                    <thead>
                      <tr>
                        <th>Türü</th>
                        <th>Başlık</th>
                        <th>Alt Başlık</th>
                        <th>Menu</th>
                        <th>Kategori</th>
                        <th>Ekleyen</th>
                        <th>Hit</th>
                        <th>Like</th>
                        <th>Eklenme Tarihi</th>
                        <th>İşlemler</th>
                      </tr>
                    </thead>
                    <tbody>";
                  if($makalequery != null)foreach ($makalequery as $value) {
                    $mastercontent.="
                      <tr>
                        <td>{$value['type_name']}</td>
                        <td class='north-east-alt' title='{$value['post_title']}'>".split_words($value['post_title'],20,"  [...]")."</td>
                        <td>";
                        if(empty($value['post_subtitle'])){
                          $mastercontent.="";
                        }
                        else{
                          $mastercontent.=$value['post_subtitle'];
                        }
                        $mastercontent.="</td>
                        <td>{$value['menu_name']}</td>
                        <td>";
                        if(empty($value['cat_name'])){
                          $mastercontent.="";
                        }
                        else{
                          $mastercontent.=$value['cat_name'];
                        }
                        $mastercontent.="</td>
                        <td>{$value['user_name']}</td>
                        <td>{$value['post_hit']}</td>
                        <td>{$value['post_like']}</td>
                        <td>".date("d-m-Y H:i:s",strtotime($value['post_addtime']))."</td>
                        <td class='text-center'>
                          <a title='Makale Oku' onclick='makaleoku({$value['post_id']})'>
                            <i class='fa fa-eye text-purple'></i>
                          </a>&nbsp;
                          <a title='Makale Güncelleme' onclick='makaleislem({$value['post_id']})'>
                            <i class='fa fa-edit text-info'></i>
                          </a>&nbsp;
                          <a title='Makale Silme' onclick='makalesil({$value['post_id']})'>
                            <i class='fa fa-trash text-danger'></i>
                          </a>
                        </td>
                      </tr>";
                    }
                    $mastercontent.="
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>";
  }
}
elseif(isset($masterurl[0]) && $masterurl[0] == "kullanicilar"){
  $masterforminfo.="Kullanıcı Ayarları Sayfası";
  $masterbreadcome.="<li><a href='#'>AnaSayfa</a><span class='bread-slash'>&nbsp;/&nbsp;</span></li>
                      <li  class='text-success'><span class='bread-blod'>Kullanıcı İşlemleri</span></li>";
  $kullanicibilgi=$dbc->fetchall("
    u.user_id,u.user_name,u.user_realname,u.user_realsurname,u.user_email,u.user_adddate,
    u.user_updatedate,us.user_status,ua.authority","
    users as u
    left join usersettings as us on  us.user_id=u.user_id
    left join userauthorities as ua on ua.authority_id=us.authority_id
    order by user_id asc");
  $mastercontent.="
    <div class='container-fluid'>
      <div class='row'>
        <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
          <div class='sparkline12-list mg-b-15 mg-t-15'>
            <div class='sparkline12-hd'>
              <div class='main-sparkline12-hd'>
                <h1>Kayıtlı Kullanıcılar</h1>
              </div>
            </div>
            <div class='row mg-b-30'>
              <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                <button class='btn btn-sm btn-primary login-submit-cs' type='submit' onclick='kullaniciislem(0,1)'>
                  <i class='fa fa-user icon-wrap'><sup class='fa fa-plus text-default'></sup></i> Yeni Kullanıcı Ekle
                </button>
              </div>
            </div>
            <div class='row mg-t-15'>
              <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                <div class='table-responsive mg-t-45'>
                  <table class='table table-hover' id='kullanicilistesi'>
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Yetkisi</th>
                        <th>Durumu</th>
                        <th>kullanıcı Adı</th>
                        <th>Adı Soyadı</th>
                        <th>Mail</th>
                        <th>Eklenme Tarihi</th>
                        <th>İşlemler</th>
                      </tr>
                    </thead>
                    <tbody>";
                  if($kullanicibilgi != null)foreach ($kullanicibilgi as $value) {
                    if($value['user_status'] == 1){
                      $durum="<button type='button' class='btn btn-custon-four btn-success btn-sm'>
                                <span class='adminpro-icon adminpro-checked-pro'></span>
                                Aktif
                              </button>";
                    }else{
                      $durum="<button type='button' class='btn btn-custon-four btn-danger btn-sm'>
                                <span class='adminpro-icon adminpro-checked-pro'></span>
                                Pasif
                              </button>";
                    }
                    $mastercontent.="
                      <tr>
                        <td>{$value['user_id']}</td>
                        <td>{$value['authority']}</td>
                        <td>{$durum}</td>
                        <td>{$value['user_name']}</td>
                        <td>{$value['user_realname']}&nbsp;{$value['user_realsurname']}</td>
                        <td>{$value['user_email']}</td>
                        <td>".date("d-m-Y H:i:s",strtotime($value['user_adddate']))."</td>
                        <td>
                          <a href='#' title='Kullanıcı Bilgi Görüntüleme' onclick='kullanicibilgileri({$value['user_id']})'>
                            <i class='fa fa-eye text-success'></i>
                          </a>&nbsp;
                          <a href='#' title='Kullanıcı Güncelleme' onclick='kullaniciislem({$value['user_id']},2)'>
                            <i class='fa fa-edit text-info'></i>
                          </a>&nbsp;
                          <a href='#' title='Kullanıcı Şifre Değitirme' onclick='kullanicisifredegisformu({$value['user_id']})'>
                            <i class='fa fa-key text-primary'></i>
                          </a>&nbsp;
                          <a href='#' title='Kullanıcı Silme' onclick='kullanicisil({$value['user_id']})'>
                            <i class='fa fa-trash text-danger'></i>
                          </a>
                        </td>
                      </tr>";
                    }
                    $mastercontent.="
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>";
}
elseif(isset($masterurl[0]) && $masterurl[0] == "media"){
	if(isset($masterurl[1]) && $masterurl[1] == "image"){
    $masterforminfo.="İmage İşlemleri Sayfası";
    $masterbreadcome.=" <li><a href='#'>AnaSayfa</a><span class='bread-slash'>&nbsp;/&nbsp;</span></li>
                        <li class='text-muted'>Media İşlemleri<span class='bread-slash'>&nbsp;/&nbsp;</span></li>
                        <li  class='text-success'><span class='bread-blod'>İmage İşlemleri</span></li>";

  $imagebilgicek=$dbc->fetchall("
    i.im_id,i.im_name,i.im_type,i.im_size,t.type,u.user_name,i.im_path,i.im_addtime,i.im_updatetime
    ","
    images as i
    left join imagesettings as ims on ims.im_id = i.im_id
    left join types as t on t.type_id = ims.type_id
    left join users as u on u.user_id = ims.user_id
    order by i.im_id asc");

    $mastercontent.="
      <div class='container-fluid'>
        <div class='row'>
          <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
            <div class='sparkline12-list mg-b-15 mg-t-15'>
              <div class='sparkline12-hd'>
                <div class='main-sparkline12-hd'>
                  <h1>Kayıtlı İmage Listesi</h1>
                </div>
              </div>
              <div class='row mg-b-30'>
                <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                  <button class='btn btn-sm btn-primary login-submit-cs' type='submit' onclick='imageislem()'>
                    <i class='fa fa-picture-o icon-wrap'><sup class='fa fa-plus text-default'></sup></i> İmage Ekle
                  </button>
                </div>
              </div>
              <div class='row mg-t-15'>
                <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                  <div class='table-responsive mg-t-45'>
                    <table class='table table-hover' id='imagelistesi'>
                      <thead>
                        <tr>
                          <th>Image</th>
                          <th>Grubu</th>
                          <th>Adı</th>
                          <th>Türü</th>
                          <th>Boyutu</th>
                          <th>Ekleyen</th>
                          <th>Eklenme Tarihi</th>
                          <th>Güncellenme Tarihi</th>
                          <th>İşlemler</th>
                        </tr>
                      </thead>
                      <tbody>";
                    if($imagebilgicek != null)foreach ($imagebilgicek as $value) {

                      $mastercontent.="
                        <tr>
                          <td><img src='../".$value['im_path'].$value['im_name']."'}></td>
                          <td>{$value['type']}</td>
                          <td>{$value['im_name']}</td>
                          <td>{$value['im_type']}</td>
                          <td>{$value['im_size']}</td>
                          <td>{$value['user_name']}</td>
                          <td>".date("d-m-Y H:i:s",strtotime($value['im_addtime']))."</td>
                          <td>".date("d-m-Y H:i:s",strtotime($value['im_updatetime']))."</td>
                          <td>
                            <a href='#' title='Kullanıcı Silme' onclick='imagesil({$value['im_id']})'>
                              <i class='fa fa-trash text-danger'></i>
                            </a>
                          </td>
                        </tr>";
                      }
                      $mastercontent.="
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>";
  }
}
else{
  /*403*/
}
 ?>
