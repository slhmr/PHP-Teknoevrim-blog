<?php
	session_start();
	unset($_SESSION['user_sssn']);
	require_once('sCache.php');
	$sCache = new sCache("",false); 
	$sCache->clearCache();
	
	if(session_destroy())
	{
		header("Location: ../index.php");
	}
?>