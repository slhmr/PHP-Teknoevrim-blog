<?php
session_start();
require_once("dbConnection.php");
require_once("functions.php");

$login = new USER();

if(!ajaxistegikontrol()){
	echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
}else{

	$sicil = VeriTemizle($_POST['sicil']);
	$sifre = VeriTemizle($_POST['sifre']);

	if($login->doLogin($sicil,$sifre)){
		 echo "Başarılı";
	}
	else{
		echo "Giriş işlemi Başarısız...!";
	}
}

?>
