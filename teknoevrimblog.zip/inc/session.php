<?php
	session_start();
	date_default_timezone_set('Europe/Istanbul');
	require_once("dbConnection.php");

	/*$session = new USER();
	if(!$session->is_loggedin())	{
		$session->redirect('index.php');
	}
*/
	?>
