<?php

require_once('config.php');

class USER{
	private $conn;
	private $sonuc = Null;

	public function __construct(){
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	public function runQuery($sql){
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}

	public function doLogin($kullaniciadi,$kullanicisifre){
		try{

			$stmt = $this->conn->prepare("SELECT u.user_id, u.user_pass, us.user_status
					FROM users AS u
				 	LEFT JOIN usersettings AS us ON us.user_id=u.user_id
					WHERE user_name = :user_name");
			$stmt->execute(array(':user_name'=>$kullaniciadi));
			$userRow=$stmt->fetch(PDO::FETCH_ASSOC);
			$durum=$userRow['user_status'];
			if($durum == 0){
				return false;
			}else{
				if($stmt->rowCount() == 1){
					if(password_verify($kullanicisifre, $userRow['user_pass'])){
						$_SESSION['user_sssn'] = $userRow['user_id'];
						return true;
					}
					else{
						return false;
					}
				}
			}
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}

	public function is_loggedin(){
		if(isset($_SESSION['user_sssn']))
		{
			return true;
		}
	}

	public function redirect($url){
		header("Location: $url");
	}

	public function doLogout(){
		session_destroy();
		unset($_SESSION['user_sssn']);
		return true;
	}

	function sql($sorgu,$veri) {

		$query = $this->conn->prepare($sorgu);
		$query->execute($veri);
		return $query;
	}

	function sqladd($tablo, $veriler) {
		$sonuc = 0;
		$alan1 = "";
		$alan2 = "";
		foreach ($veriler as $anahtar => $deger) {
			$alan1 .= $anahtar . ",";
			$alan2 .= ":".$anahtar.",";
		}
		$alan1 = substr($alan1,0,strlen($alan1)-1);
		$alan2 = substr($alan2,0,strlen($alan2)-1);
		$query = $this->conn->prepare("INSERT INTO ".$tablo." (".$alan1.") VALUES (".$alan2.")");
		$query->execute($veriler);
		if ( $query ){
			if($this->conn->lastInsertId()){
				$sonuc = $this->conn->lastInsertId();
			}else{
				$sonuc = "YES";
			}
		}else $sonuc = "NO";
		return $sonuc;
	}

	function sqlupdate($tablo, $veriler, $where="") {
        $sonuc = "";
        $alan = "";
        foreach ($veriler as $anahtar => $deger) $alan .= $anahtar . "= :".$anahtar.",";
        $alan = substr($alan,0,strlen($alan)-1);
        if($where!="") $where = " WHERE ".$where;
        $query = $this->conn->prepare("UPDATE ".$tablo." SET ".$alan.$where);
        $update = $query->execute($veriler);
        if ( $update ){
			if($query->rowCount()>0){
				$sonuc = $query->rowCount();
			}else{
				$sonuc = "YES";
			}
		}else{
			$sonuc = "NO";
		}
        return $sonuc;
    }

	function sqldelete($tablo,$where) {
        $delete = $this->conn->exec("DELETE FROM ".$tablo." WHERE ".$where);
        return $delete;
    }

	function fetchall($sutun,$diger,$parametre = array())
	{
		$sorgu = $this->conn->prepare("SELECT ".$sutun." FROM ".$diger);
		$sorgu->execute($parametre);
		if(!empty($sorgu))
		{
			$this->sonuc = $sorgu->fetchAll(PDO::FETCH_ASSOC);
		}
		return $this->sonuc;
	}

	function fetchline($sutun,$diger,$parametre = array())
	{
		$sorgu = $this->conn->prepare("SELECT ".$sutun." FROM ".$diger);
		$sorgu->execute($parametre);
		if(!empty($sorgu))
		{
			$this->sonuc = $sorgu->fetch(PDO::FETCH_ASSOC);
		}
		return $this->sonuc;
	}

	function fetchcell($sutun,$diger,$parametre = array())
	{
		$sorgu = $this->conn->prepare("SELECT ".$sutun." FROM ".$diger);
		$sorgu->execute($parametre);
		if(!empty($sorgu))
		{
			$this->sonuc = $sorgu->fetch(PDO::FETCH_ASSOC);
			if(empty($this->sonuc)){
				$this->sonuc = "";
			}else{
				$this->sonuc = $this->sonuc[$sutun];
			}
		}
		return $this->sonuc;
	}

}
?>
