<?php
require_once('session.php');
$dbc = new user();
require_once("functions.php");
$sayfa = clearData(isset($_GET["tke"]) ? $_GET["tke"] : "tke");
$parametre = explode("/",$sayfa);

if($parametre[0] == "likes"){
	if(!ajaxRquestCheck()){
		 echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	 }
	 else{
		$postid	=	clearData($_POST['postid']);
		$deger 	=	clearData($_POST['deger']);

		if(!empty($postid)){
			$likesorgu=$dbc->fetchall("post_like","postsettings where post_id =:postid",array("postid"=>$postid));
			if($likesorgu != null)foreach ($likesorgu as $value) {
				$likesorgu=$value['post_like'];
				if($deger == 1){
					$likesorgu=$likesorgu+1;
					$likdeupdate=$dbc->sqlupdate("postsettings",array("post_like"=>$likesorgu),"post_id = '{$postid}'");
					if($likdeupdate >0 || $likdeupdate=='YES'){
						$data['durum']="Basarili";
						$data['like']=$likesorgu;
						$data['deger']=2;
						$data['id']=$postid;
					}
					else{
							$data['durum']="Basarisiz";
					}
				}
				elseif($deger == 2)	{
					$likesorgu=$likesorgu-1;
					$likdeupdate=$dbc->sqlupdate("postsettings",array("post_like"=>$likesorgu),"post_id = '{$postid}'");
					if($likdeupdate >0 || $likdeupdate=='YES'){
						$data['durum']="Basarili";
						$data['like']=$likesorgu;
						$data['deger']=1;
						$data['id']=$postid;
					}
					else{
							$data['durum']="Basarisiz";
					}
				}
				else{
						$data['durum']="islem tur bilgisi alınamdı";
				}
			}
			else{
				$data['durum']="like bilgisi alınamdı";
			}
		}
		else{
			$data['durum']="post ıd bulunamadı";
		}
		echo  Json_encode($data);
	}
}
if($parametre[0] == "subscribe"){
	if(!ajaxRquestCheck()){
		 echo 'Hoooops Bu Yaptığın İşlem Ajax İsteği Değil...!';
	 }
	 else{
		 $email	=	clearData($_POST['email']);
		 if(!empty($email)){
			 $kontrol=$dbc->fetchall("news_mail,news_status","newsletter where news_mail='$email'",array());
			 $kayitsayisi=count($kontrol);
			 if($kayitsayisi > 0){
				 if($kontrol != null)foreach ($kontrol as $value) {
				 		$abonelikdurum=$value['news_status'];
				 }
				 if($abonelikdurum == 'pending'){
					 $data['type']="info";
				 }else{
					 $data['type']="error";
				 }
			 }else{
				 $mailekle=$dbc->sqladd("newsletter",array("news_mail"=>$email));
				 if($mailekle > 0){
					 	$data['baslik']="Abonelik Başvurunuz Tarafımıza İletildi...";
					 	$data['mesaj']="$email isimli Adresinize Doğrulma Linki Gönderdik. Doğrulama Linkini Tıklayarak Aboneli İşlemini Tamamlamanız Gerekmektedir..";
					 	$data['type']="success";
				 }else{
						$data['baslik']="Abonelik Başvurunuz Sırasında Bir Hata Meydana Geldi";
						$data['mesaj']="Daha Sonra Tekrar Deneyiniz..";
						$data['type']="error";
				 }
			 }
		 }
		 echo  Json_encode($data);
	 }
 }
?>
