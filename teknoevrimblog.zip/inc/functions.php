<?php

/*Yararlı Fonksiyonlar*/
function getUrl(){
  $dirname = dirname($_SERVER['SCRIPT_NAME']);
  $dirname = $dirname != '/' ? $dirname : null;
  $basename = basename($_SERVER['SCRIPT_NAME']);
  $request_url = str_replace([$dirname, $basename], null, $_SERVER['REQUEST_URI']);
  return $request_url;
}
function replaceSpace($string){
	$string = preg_replace("/\s+/", "", $string);
	$string = trim($string);
	return $string;
}
function isInteger($input){
  return preg_match('@^[1-9][0-9]*$@',$input) === 1;
}
function ajaxRquestCheck(){
    $header = isset($_SERVER['HTTP_X_REQUESTED_WITH']) ? $_SERVER['HTTP_X_REQUESTED_WITH'] : null;
    return ($header === 'XMLHttpRequest');
}
function mtd($to, $str) {
    $cs = 'utf-8';
    if (!function_exists('rp')):
        function rp($i, $str) {
            $B = array('I', 'Ğ', 'Ü', 'Ş', 'İ', 'Ö', 'Ç');
            $k = array('ı', 'ğ', 'ü', 'ş', 'i', 'ö', 'ç');
            $Bi = array(' I', ' ı', ' İ', ' i');
            $ki = array(' I', ' I', ' İ', ' İ');
            if ($i == 1):
                return str_replace($B, $k, $str);
            elseif ($i == 2):
                return str_replace($k, $B, $str);
            elseif ($i == 3):
                return str_replace($Bi, $ki, $str);
            endif;
        }
    endif;
    if (!function_exists('cf')):
        function cf($c = array(), $str) {
            foreach ($c as $cc) {
                $s = explode($cc, $str);
                foreach ($s as $k => $ss) {
                    $s[$k] = mtd('ilk', $ss);
                }
                $str = implode($cc, $s);
            }
            return $str;
        }
    endif;
    if (!function_exists('te')):
        function te() {
            return trigger_error('Lütfen geçerli bir  parametre giriniz.', E_USER_ERROR);
        }
    endif;
    $to = explode('|', $to);
    if ($to):
        foreach ($to as $t) {
            if ($t == 'Kucuk'):
                $str = mb_strtolower(rp(1, $str), $cs);
            elseif ($t == 'buyuk'):
                $str = mb_strtoupper(rp(2, $str), $cs);
            elseif ($t == 'ilk'):
                $str = mb_strtoupper(rp(2, mb_substr($str, 0, 1, $cs)), $cs) . mb_substr($str, 1, mb_strlen($str, $cs) - 1, $cs);
            elseif ($t == 'baslik'):
                $str = ltrim(mb_convert_case(rp(3, ' ' . $str), MB_CASE_TITLE, $cs));
            else:
                $str = te();
            endif;
        }
    else:
        $str = te();
    endif;
    return $str;
}
function create_url_title ($baslik=""){
  $TR=array('ç','Ç','ı','İ','ş','Ş','ğ','Ğ','ö','Ö','ü','Ü');
  $EN=array('c','c','i','i','s','s','g','g','o','o','u','u');
  $baslik= str_replace($TR,$EN,$baslik);
  $baslik=mb_strtolower($baslik,'UTF-8');
  $baslik=preg_replace('#[^-a-zA-Z0-9_ ]#','',$baslik);
  $baslik=trim($baslik);
  $baslik= preg_replace('#[-_ ]+#','-',$baslik);
  return $baslik;
}
function create_full_url($id, $baslik=null){

   return sprintf('%s/%s',"dtl",create_url_title($baslik)."-".$id);

}
function CreateRandomPass($length,$row){
		$veri = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$veri .= "abcdefghijklmnopqrstuvwxyz";
		$veri .= "0123456789!@#$%^&*()_+";
		$all_password = "";
		for($i=1;$i<=$row;$i++){
			$password = "";
			while(strlen($password) < $length){
				$password .= substr($veri,(rand() % strlen($veri)),1);
			}
			$all_password .= $password."<br />";
		}
		return($all_password);
	}
function createPass($password) {
    if (defined("CRYPT_BLOWFISH") && CRYPT_BLOWFISH) {
        $salt = '$2y$11$' . substr(sha1(md5(uniqid(rand(), true))), 0, 32);
        return crypt($password, $salt);
    }
}
function percent($x,$y){
    $z = $x / 100;
    echo floor($y / $z);
  }
function size($bytes){      /*B KB MB GB donüştürme */
    if ($bytes > 0){
        $unit = intval(log($bytes, 1024));
        $units = array('B', 'KB', 'MB', 'GB', 'TB', 'PB');
        if (array_key_exists($unit, $units) === true) {
            return sprintf('%d %s', $bytes / pow(1024, $unit), $units[$unit]);
        }
    }
    return $bytes;
}

function checkSession(){
	if(isset($_SESSION['user_sssn']) ==''){
	    header('location:login.php');
	    exit();
	}
}

function clearData($data){
  if(is_array($data)){
    foreach($data as $key => $value){
      if(is_array($value)){
        $data[$key] = TemizVeri($value);
      }else{
		$data[$key] = htmlspecialchars(strip_tags(urldecode(addslashes(stripslashes(trim(htmlspecialchars_decode(trim($value))))))));
      }
    }
  }else{
    $data = htmlspecialchars(strip_tags(urldecode(addslashes(stripslashes(trim(htmlspecialchars_decode(trim($data))))))));
  }
  return $data;
}
function Wmonth($x){
	$donustur = array(
        '01' => '1',
        '02' => '2',
        '03' => '3',
        '04' => '4',
        '05' => '5',
        '06' => '6',
        '07' => '7',
        '08' => '8',
        '09' => '9',
        '10' => '10',
        '11' => '11',
        '12' => '12',
    );
    $y=$donustur[$x];
 	$aylar =array("","Oca","Şub","Mar","Nis","May","Haz","Tem","Ağu","Eyl","Eki","Kas","Ara");

 return $aylar[$y];
}
function split_words($string, $nb_caracs, $separator){
    $string = strip_tags(html_entity_decode($string));
    if( strlen($string) <= $nb_caracs ){
        $final_string = $string;
    } else {
        $final_string = "";
        $words = explode(" ", $string);
        foreach( $words as $value ){
            if( strlen($final_string . " " . $value) < $nb_caracs ){
                if( !empty($final_string) ) $final_string .= " ";
                $final_string .= $value;
            } else {
                break;
            }
        }
        $final_string .= $separator;
    }
    return $final_string;
}
function getIP(){
  $ipaddress = '';
  if (isset($_SERVER['HTTP_CLIENT_IP']))
    $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
  else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
    $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
  else if(isset($_SERVER['HTTP_X_FORWARDED']))
    $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
  else if(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
    $ipaddress = $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
  else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
    $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
  else if(isset($_SERVER['HTTP_FORWARDED']))
    $ipaddress = $_SERVER['HTTP_FORWARDED'];
  else if(isset($_SERVER['REMOTE_ADDR']))
    $ipaddress = $_SERVER['REMOTE_ADDR'];
  else
    $ipaddress = 'UNKNOWN';
  return $ipaddress;
  }


function geoCheckIP($ip){

  if(!filter_var($ip, FILTER_VALIDATE_IP) || $ip == 'localhost'){
      return false;
  }
  $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
  if (empty($ipdat)){
      return false;
  }
  $patterns=array();
  $patterns["countryName"]    = $ipdat->geoplugin_countryName;
  $patterns["countryCode"]    = $ipdat->geoplugin_countryCode;
  $patterns["city"]           = $ipdat->geoplugin_city;
  $patterns["continentName"]  = $ipdat->geoplugin_continentName;
  $patterns["latitude"]       = $ipdat->geoplugin_latitude;
  $patterns["longitude"]      = $ipdat->geoplugin_longitude;
  $patterns["timezone"]       = $ipdat->geoplugin_timezone;
  $patterns["region"]         = $ipdat->geoplugin_region;
  return $patterns;
}
function gecensure($date){

$today = date('Y-m-d H:i:s');
$today_seconds = strtotime($today);
$date_seconds = strtotime($date);
$diff = $today_seconds - $date_seconds;

if($diff > 0 && $diff < 60){
  $passed_time = $diff." Saniye Önce";
}else if($diff >= 60 && $diff < 60*60){
  $minute = floor($diff / 60);
  $passed_time = $minute." Dakika Önce";
}else if($diff >= 60*60 && $diff < 60*60*24 ){
  $hour = floor($diff/60/60);
  $passed_time = $hour." Ssaat Önce";
}else if($diff >= 60*60*24 && $diff < 60*60*24*7){
  $day = floor($diff/60/60/24);
  $passed_time = $day." Gün Önce";
}else if($diff >= 60*60*24*7 && $diff < 60*60*24*30 ){
  $week = floor($diff/60/60/24/7);
  $passed_time = $week." Hafta Önce";
}else if($diff >= 60*60*24*30 && $diff < 60*60*24*30*12 ){
  $month = floor($diff/60/60/24/30);
  $passed_time = $month." Ay Önce";
}else if($diff >= 60*60*24*30*12){
  $year = floor($year/60/60/24/30/12);
  $passed_time = $year." Yıl Önce";
}else{
  $passed_time = "Geçersiz Zaman Dilimi";
}

return $passed_time;

}
function getBrowserType (){
if (!empty($_SERVER['HTTP_USER_AGENT']))
{
  $HTTP_USER_AGENT = $_SERVER['HTTP_USER_AGENT'];
}
else if (!empty($HTTP_SERVER_VARS['HTTP_USER_AGENT']))
{
  $HTTP_USER_AGENT = $HTTP_SERVER_VARS['HTTP_USER_AGENT'];
}
else if (!isset($HTTP_USER_AGENT))
{
  $HTTP_USER_AGENT = '';
}
if (preg_match('#Opera(/| )([0-9].[0-9]{1,2})#', $HTTP_USER_AGENT, $log_version))
{
  $browser_version = $log_version[2];
  $browser_agent = 'Opera';
}
else if (preg_match('#MSIE ([0-9].[0-9]{1,2})#', $HTTP_USER_AGENT, $log_version))
{
  $browser_version = $log_version[1];
  $browser_agent = 'IE';
}
else if (preg_match('#OmniWeb/([0-9].[0-9]{1,2})#', $HTTP_USER_AGENT, $log_version))
{
  $browser_version = $log_version[1];
  $browser_agent = 'OmniWeb';
}
else if (preg_match('#Netscape([0-9]{1})#', $HTTP_USER_AGENT, $log_version))
{
  $browser_version = $log_version[1];
  $browser_agent = 'Netscape';
}
else if (preg_match('#Mozilla/([0-9].[0-9]{1,2})#', $HTTP_USER_AGENT, $log_version))
{
  $browser_version = $log_version[1];
  $browser_agent = 'Mozilla';
}
else if (preg_match('#Konqueror/([0-9].[0-9]{1,2})#', $HTTP_USER_AGENT, $log_version))
{
  $browser_version = $log_version[1];
  $browser_agent = 'konqueror';
}
else
{
  $browser_version = 0;
  $browser_agent = 'other';
}
return $browser_agent;
}
function getOS(){
    if(!isset($user_agent) && isset($_SERVER['HTTP_USER_AGENT'])) {
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
    }

    // https://stackoverflow.com/questions/18070154/get-operating-system-info-with-php
    $os_array = [
        'windows nt 10'                              =>  'Windows 10',
        'windows nt 6.3'                             =>  'Windows 8.1',
        'windows nt 6.2'                             =>  'Windows 8',
        'windows nt 6.1|windows nt 7.0'              =>  'Windows 7',
        'windows nt 6.0'                             =>  'Windows Vista',
        'windows nt 5.2'                             =>  'Windows Server 2003/XP x64',
        'windows nt 5.1'                             =>  'Windows XP',
        'windows xp'                                 =>  'Windows XP',
        'windows nt 5.0|windows nt5.1|windows 2000'  =>  'Windows 2000',
        'windows me'                                 =>  'Windows ME',
        'windows nt 4.0|winnt4.0'                    =>  'Windows NT',
        'windows ce'                                 =>  'Windows CE',
        'windows 98|win98'                           =>  'Windows 98',
        'windows 95|win95'                           =>  'Windows 95',
        'win16'                                      =>  'Windows 3.11',
        'mac os x 10.1[^0-9]'                        =>  'Mac OS X Puma',
        'macintosh|mac os x'                         =>  'Mac OS X',
        'mac_powerpc'                                =>  'Mac OS 9',
        'linux'                                      =>  'Linux',
        'ubuntu'                                     =>  'Linux - Ubuntu',
        'iphone'                                     =>  'iPhone',
        'ipod'                                       =>  'iPod',
        'ipad'                                       =>  'iPad',
        'android'                                    =>  'Android',
        'blackberry'                                 =>  'BlackBerry',
        'webos'                                      =>  'Mobile',
        '(media center pc).([0-9]{1,2}\.[0-9]{1,2})'=>'Windows Media Center',
        '(win)([0-9]{1,2}\.[0-9x]{1,2})'=>'Windows',
        '(win)([0-9]{2})'=>'Windows',
        '(windows)([0-9x]{2})'=>'Windows',
        'Win 9x 4.90'=>'Windows ME',
        '(windows)([0-9]{1,2}\.[0-9]{1,2})'=>'Windows',
        'win32'=>'Windows',
        '(java)([0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2})'=>'Java',
        '(Solaris)([0-9]{1,2}\.[0-9x]{1,2}){0,1}'=>'Solaris',
        'dos x86'=>'DOS',
        'Mac OS X'=>'Mac OS X',
        'Mac_PowerPC'=>'Macintosh PowerPC',
        '(mac|Macintosh)'=>'Mac OS',
        '(sunos)([0-9]{1,2}\.[0-9]{1,2}){0,1}'=>'SunOS',
        '(beos)([0-9]{1,2}\.[0-9]{1,2}){0,1}'=>'BeOS',
        '(risc os)([0-9]{1,2}\.[0-9]{1,2})'=>'RISC OS',
        'unix'=>'Unix',
        'os/2'=>'OS/2',
        'freebsd'=>'FreeBSD',
        'openbsd'=>'OpenBSD',
        'netbsd'=>'NetBSD',
        'irix'=>'IRIX',
        'plan9'=>'Plan9',
        'osf'=>'OSF',
        'aix'=>'AIX',
        'GNU Hurd'=>'GNU Hurd',
        '(fedora)'=>'Linux - Fedora',
        '(kubuntu)'=>'Linux - Kubuntu',
        '(ubuntu)'=>'Linux - Ubuntu',
        '(debian)'=>'Linux - Debian',
        '(CentOS)'=>'Linux - CentOS',
        '(Mandriva).([0-9]{1,3}(\.[0-9]{1,3})?(\.[0-9]{1,3})?)'=>'Linux - Mandriva',
        '(SUSE).([0-9]{1,3}(\.[0-9]{1,3})?(\.[0-9]{1,3})?)'=>'Linux - SUSE',
        '(Dropline)'=>'Linux - Slackware (Dropline GNOME)',
        '(ASPLinux)'=>'Linux - ASPLinux',
        '(Red Hat)'=>'Linux - Red Hat',
        'X11'=>'Unix',
        '(linux)'=>'Linux',
        '(amigaos)([0-9]{1,2}\.[0-9]{1,2})'=>'AmigaOS',
        'amiga-aweb'=>'AmigaOS',
        'amiga'=>'Amiga',
        'AvantGo'=>'PalmOS',
        '(Linux)([0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,3}(rel\.[0-9]{1,2}){0,1}-([0-9]{1,2}) i([0-9]{1})86){1}'=>'Linux',
        '(Linux)([0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,3}(rel\.[0-9]{1,2}){0,1} i([0-9]{1}86)){1}'=>'Linux',
        '(Linux)([0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,3}(rel\.[0-9]{1,2}){0,1})'=>'Linux',
        '[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,3})'=>'Linux',
        '(webtv)/([0-9]{1,2}\.[0-9]{1,2})'=>'WebTV',
        'Dreamcast'=>'Dreamcast OS',
        'GetRight'=>'Windows',
        'go!zilla'=>'Windows',
        'gozilla'=>'Windows',
        'gulliver'=>'Windows',
        'ia archiver'=>'Windows',
        'NetPositive'=>'Windows',
        'mass downloader'=>'Windows',
        'microsoft'=>'Windows',
        'offline explorer'=>'Windows',
        'teleport'=>'Windows',
        'web downloader'=>'Windows',
        'webcapture'=>'Windows',
        'webcollage'=>'Windows',
        'webcopier'=>'Windows',
        'webstripper'=>'Windows',
        'webzip'=>'Windows',
        'wget'=>'Windows',
        'Java'=>'Unknown',
        'flashget'=>'Windows',
        'MS FrontPage'=>'Windows',
        '(msproxy)/([0-9]{1,2}.[0-9]{1,2})'=>'Windows',
        '(msie)([0-9]{1,2}.[0-9]{1,2})'=>'Windows',
        'libwww-perl'=>'Unix',
        'UP.Browser'=>'Windows CE',
        'NetAnts'=>'Windows',
    ];
    $arch_regex = '/\b(x86_64|x86-64|Win64|WOW64|x64|ia64|amd64|ppc64|sparc64|IRIX64)\b/ix';
    $arch = preg_match($arch_regex, $user_agent) ? '64' : '32';

    foreach ($os_array as $regex => $value) {
        if (preg_match('{\b('.$regex.')\b}i', $user_agent)) {
            return $value.' x'.$arch;
        }
    }

    return 'Unknown OS Platform';
  }
function getReferer(){
  if ( ! empty( $_SERVER['HTTP_REFERER'] ) ){
    return $_SERVER['HTTP_REFERER'];
  }
  return false;
}
function getRequestURI() {
  if ( ! empty( $_SERVER['REQUEST_URI'] ) ){
    $uri = $_SERVER['REQUEST_URI'];
    return $uri;
  }
  return false;
}
  function blogvisitorcounter() {
    $ip         = getIP();
    $browser    = getBrowserType();
    $OS         = getOS();

    online($ip,$browser,$OS);
    visitor($ip,$browser,$OS);
  }
function online ($ip,$browser,$OS){
  global $dbc;
  $past       = time()-150;

  $onlinedelete = $dbc->sqldelete("online","time < $past");
  $onlinecontrol = $dbc->fetchall("*","online WHERE ip='$ip'");

  if(count($onlinecontrol) > 0){
  	$update = $dbc->sqlupdate("online",array("ip"=>$ip,"time"=>time()),"ip ='$ip'");
  }
  else{
  	$add= $dbc->sqladd("online",array("ip"=>$ip, "time"=>time(), "browser"=>$browser,"OS"=>$OS));
  }
}
function visitor ($ip,$browser,$OS){
  global $dbc;
  $location   = geoCheckIP($ip);
  $referer    = getReferer();
  $page       = getRequestURI();

  $sondk = gmDate("H:i:s");
  $bugun = date("Y-m-d H:i:s");
  $sonuc = $dbc->sqlupdate("visit",array("lastvisit"=>$sondk),"time='$bugun' and ip='$ip'");

  $ipkontrol = $dbc->fetchall("*","visit WHERE ip='$ip'");
  if($ipkontrol != null )foreach ($ipkontrol as $satir ) {
  	$vip = $satir['ip'];
  	$vtarih = $satir['time'];
  	$vsondk = $satir['lastvisit'];
  }
if(count($ipkontrol) > 0){
	if($vtarih < date("Y-m-d H:i:s")){
		$sonuc = $dbc->sqladd("visit",
      array(
        "ip" => $ip, "os" => $OS,"browser" => $browser, "continentName" => $location["continentName"],
        "countryName" => $location["countryName"], "countryCode" => $location["countryCode"],
        "city" => $location["city"], "latitude" => $location["latitude"],"longitude" => $location["longitude"],
        "region" => $location["region"],"lastvisit" => $sondk,"referer" => $referer,"page" => $page));
  }
}
else{
  $sonuc = $dbc->sqladd("visit",
    array(
      "ip" => $ip, "os" => $OS,"browser" => $browser, "continentName" => $location["continentName"],
      "countryName" => $location["countryName"], "countryCode" => $location["countryCode"],
      "city" => $location["city"], "latitude" => $location["latitude"],"longitude" => $location["longitude"],
      "region" => $location["region"],"lastvisit" => $sondk,"referer" => $referer,"page" => $page));
	}

}

  function makeThumbnails($updir, $img, $id){
    $thumbnail_width = 134;
    $thumbnail_height = 189;
    $thumb_beforeword = "thumb";
    $arr_image_details = getimagesize("$updir" . $id . '_' . "$img");
    $original_width = $arr_image_details[0];
    $original_height = $arr_image_details[1];
    if ($original_width > $original_height) {
      $new_width = $thumbnail_width;
      $new_height = intval($original_height * $new_width / $original_width);
    } else {
      $new_height = $thumbnail_height;
      $new_width = intval($original_width * $new_height / $original_height);
    }
    $dest_x = intval(($thumbnail_width - $new_width) / 2);
    $dest_y = intval(($thumbnail_height - $new_height) / 2);
    if ($arr_image_details[2] == IMAGETYPE_GIF) {
      $imgt = "ImageGIF";
      $imgcreatefrom = "ImageCreateFromGIF";
    }
    if ($arr_image_details[2] == IMAGETYPE_JPEG) {
      $imgt = "ImageJPEG";
      $imgcreatefrom = "ImageCreateFromJPEG";
    }
    if ($arr_image_details[2] == IMAGETYPE_PNG) {
      $imgt = "ImagePNG";
      $imgcreatefrom = "ImageCreateFromPNG";
    }
    if ($imgt) {
      $old_image = $imgcreatefrom("$updir" . $id . '_' . "$img");
      $new_image = imagecreatetruecolor($thumbnail_width, $thumbnail_height);
      imagecopyresized($new_image, $old_image, $dest_x, $dest_y, 0, 0, $new_width, $new_height, $original_width, $original_height);
      $imgt($new_image, "$updir" . $id . '_' . "$thumb_beforeword" . "$img");
    }
  }
  function ImageResize($width, $height, $img_name, $uzanti)  {
    list($w, $h) = getimagesize($img_name);

    $ratio = max($width/$w, $height/$h);
    $h = ceil($height / $ratio);
    $x = ($w - $width / $ratio) / 2;
    $w = ceil($width / $ratio);
    $path = $img_name;

    if($uzanti  ==  'image/jpeg'){
      $imgString = file_get_contents($img_name);
      $image = imagecreatefromstring($imgString);
      $tmp = imagecreatetruecolor($width, $height);
      imagecopyresampled($tmp, $image, 0, 0, $x, 0, $width, $height, $w, $h);
      imagejpeg($tmp, $path, 100);
    }
    else if($uzanti ==  'image/png'){
      $image = imagecreatefrompng($img_name);
      $tmp = imagecreatetruecolor($width,$height);
      imagealphablending($tmp, false);
      imagesavealpha($tmp, true);
      imagecopyresampled($tmp, $image,0,0,$x,0,$width,$height,$w, $h);
      imagepng($tmp, $path, 0);
    }
    else if($uzanti ==  'image/gif')  {
      $image = imagecreatefromgif($img_name);
      $tmp = imagecreatetruecolor($width,$height);

      $transparent = imagecolorallocatealpha($tmp, 0, 0, 0, 127);
      imagefill($tmp, 0, 0, $transparent);
      imagealphablending($tmp, true);

      imagecopyresampled($tmp, $image,0,0,0,0,$width,$height,$w, $h);
      imagegif($tmp, $path);
    }
  else{
      return false;
    }

    return true;
    imagedestroy($image);
    imagedestroy($tmp);
  }
?>
