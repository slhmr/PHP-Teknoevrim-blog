<?php
echo "
	<div class='modal-primary modal modal-adminpro-general default-popup-PrimaryModal fade' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'></div>
	<div class='modal-info modal modal-adminpro-general fullwidth-popup-InformationproModal fade' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'></div>
	<div class='modal-warning modal modal-adminpro-general Customwidth-popup-WarningModal fade' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'></div>
	<div class='modal-danger modal modal-adminpro-general FullColor-popup-DangerModal fade' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'></div>
	<div class='modal-alert modal modal-adminpro-general FullColor-popup-AlertModal fade' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'></div>
	";
?>
