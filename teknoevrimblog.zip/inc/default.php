<?php
$content="";
$mastercontent="";
$icerik="";
$breadcrumb="";
$masterbreadcome="";
$masterforminfo="";
define("anadizin","/TeknoEvrim/");
define("defaultpage","/TeknoEvrim");
define("style","/TeknoEvrim/view/style");
define("loginstyle","view/style/");
define("footerbilgi","  Copyrights &copy; 2020 Tüm hakları saklıdır.  <a href='http://mavrosoft.teknoevrim.net/' target='_blank'>mavrosoft</a> tarafından derlenerek kodlanmıştır.</p>");

?>
