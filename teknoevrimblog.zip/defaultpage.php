<?php
$breadcrumb.="<li>AnaSayfa</li>";
if(empty($url[1])){
	$sayfa=1;
}else{
	$sayfa=$url[1];
}
$toplamverisayisi=$dbc->fetchall("p.post_id
		","
		posts AS p
		LEFT JOIN postsettings AS ps ON ps.post_id = p.post_id
		LEFT JOIN menus AS m ON m.menu_id = ps.menu_id
		LEFT JOIN categories AS c ON c.cat_id = ps.cat_id
		LEFT JOIN posttypes AS t ON t.type_id = ps.type_id
		LEFT JOIN users AS u ON u.user_id = ps.user_id
		ORDER BY p.post_id DESC
	",array());
	$toplamverisayisi=count($toplamverisayisi);
	if($toplamverisayisi > 0){
		$Sayfa_Sayisi = ceil($toplamverisayisi/$Limit);if($sayfa > $Sayfa_Sayisi){$sayfa = 1;}
		$Goster = $sayfa * $Limit - $Limit;
		$sorgupost=$dbc->fetchall("p.post_id,p.post_title,p.post_subtitle,p.post_link,
			p.post_content,p.post_addtime,c.cat_id,c.cat_name,c.cat_link,m.menu_name,
			m.menu_link,m.menu_id,t.type_name,t.type_id,u.user_name,ps.post_like,ps.post_hit
			","
			posts AS p
			LEFT JOIN postsettings AS ps ON ps.post_id = p.post_id
			LEFT JOIN menus AS m ON m.menu_id = ps.menu_id
			LEFT JOIN categories AS c ON c.cat_id = ps.cat_id
			LEFT JOIN posttypes AS t ON t.type_id = ps.type_id
			LEFT JOIN users AS u ON u.user_id = ps.user_id
			ORDER BY p.post_id DESC limit $Goster,$Limit
		",array());
		if($sorgupost != null)foreach ($sorgupost as $value) {
			$postid=$value['post_id'];
			$tarih=explode(" ",$value['post_addtime']);
			$aygun=explode("-",$tarih[0]);
			if(!empty($value['cat_link'])){
				$link=create_full_url($value['post_id'],$value['post_title']);
			}else{
					$link=create_full_url($value['post_id'],$value['post_title']);
			}


			$content.="
			<article class='article'>
				<div class='article-meta-date'>
					<span>".date("d",strtotime($value['post_addtime']))."</span>
							".Wmonth(date("m",strtotime($value['post_addtime'])))."
						</span>
					</div>
					<h2><a class='uhover-shadow hover-color' href='?pg=".$link."'>{$value['post_title']}</a></h2>
					<div class='article-meta-container clearfix  sm-margin'>
						<div class='article-meta-more'>
							<a href='#'><span class='separator'><i class='fa fa-user'></i></span>By {$value['user_name']}</a>
							<a href='#'><span class='separator'><i class='fa fa-comments '></i></span>3 Comments</a>
							<a href='?pg=".$value['menu_link']."'><span class='separator'><i class='fa fa-tag'></i></span>{$value['menu_name']}</a>
						</div><!-- End. pull-left -->
						<div class='article-meta-view'>
							<a href='#'><span class='separator'><i class='fa fa-eye '></i></span>	<small class='post-count'>{$value['post_hit']}</small></a>
							<a><span class='separator'><i class='fa fa-heart likebutonu-{$postid}' onclick='likes({$postid},1)'></i></span><small class='post-count like-count-{$postid}'>{$value['post_like']}</small></a>
						</div>
						</div><!-- End .article-meta-container -->";
					if($value['type_id']==5){
						$content.="
							<div class='video-responsive article-media-container sm-margin'>
								<iframe width='100%' height='59%' src='http://www.youtube.com/embed/{$value['post_link']}' allowfullscreen></iframe>
							</div>
							";
					}
				$content.="
					<div class='article-content-container'>
					<p>".split_words(htmlspecialchars_decode($value['post_content']),250,"  [...]")."</p>
						<a class='btn btn-custom-2 text-uppercase' href='?pg=".$link."'  role='button'> Devamını Oku</a>

				</div><!-- End .article-content-container -->
			</article><!-- End .article -->";
		}

	$content.= "<div class='pull-right pagi col-md-12'>
								<ul><hr/>";
								if($sayfa > 1){
									$content.= "<li><a href='?pg=".$url[0]."/".($sayfa - 1)."'>Önceki</a></li>";
								}
								for($i = $sayfa - $GorunenSayfa; $i < $sayfa + $GorunenSayfa +1; $i++){
									if($i > 0 and $i <= $Sayfa_Sayisi){
										if($i == $sayfa){
												$content.="<li><span class='active'>{$i}</span></li>";
										}else{
											$content.= "<li><a href='?pg=".$url[0]."/".$i."'>".$i."</a></li>";
										}
									}
								}
									if($sayfa != $Sayfa_Sayisi){
										$content.= "<li><a href='?pg=".$url[0]."/".($sayfa + 1)."'>Sonraki</a></li>";
									}

		$content.= "</ul></div>";
	}else{
		$content.= "<div class='info'>Gösterilecek İçerik Bulunmamaktadır...</div>";
	}
?>
