<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
require_once("inc/session.php");
$dbc = new user();
require_once("inc/functions.php");
require_once("inc/default.php");
require_once("inc/pagination.php");


include "inc/modal.php";
include "view/header.php";
blogvisitorcounter();
$pg = isset($_GET["pg"]) ? $_GET["pg"] : "pg";
$url = explode("/",$pg);
$mlink="";
$clink="";
$mlink=$dbc->fetchcell("menu_link","menus where menu_link='".$url[0]."'",array());
$clink=$dbc->fetchcell("cat_link","categories where cat_link='".$url[0]."'",array());
if($url[0] == "pg" && !isset($url[1])){
	echo "<script language='JavaScript'>window.location='?pg=anaSayfa'</script>";exit();
}
$Limit = 3;
$GorunenSayfa = 4;

switch ($url[0]) {
	case ($url[0] == $mlink) ||($url[0] == $clink) :	require_once("process.php");	break;
	case  'anaSayfa'			: require_once("view/defaultpage.php");	break;
  case  'dtl'						:	require_once("process.php");	break;
	default								:	break;
}

include "view/content.php";
include "view/sidebar.php";
include "view/footer.php";
?>
